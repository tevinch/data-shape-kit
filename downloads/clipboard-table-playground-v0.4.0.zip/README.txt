# Clipboard Table — local browser playground v0.4.0

1. Extract this archive and open index.html in a modern browser.
2. Choose TSV (tabs) for copied spreadsheet cells, or CSV (commas) for CSV text.
3. Paste text or choose Load example. Select CSV, JSON or Markdown table.
4. Copy the complete result or download a .csv, .json or .md file.

For a small spreadsheet selection, choose TSV input and CSV output. CSV
includes every input row, including the first. Its heading checkbox affects
only the preview. Every cell is quoted, quotes inside cells are doubled,
and records use CRLF. Empty cells, duplicate/blank headings, unequal row
widths and literal text are retained, without padding or type inference.
Extra preview columns beyond the first row get generated Column N labels.
The CSV download adds one final CRLF; copying uses no final separator.
Use Download CSV to retain serialized line endings. Manual copying from
the output text box may normalize them. Receiving applications can still
convert numbers or evaluate formula-looking text; quoting does not stop it.

JSON's heading option produces objects with unique, nonblank keys and
equal-width rows; turn it off for arrays retaining unequal row widths.
Markdown always requires equal-width rows. Its heading option uses row1
as headings; turning it off generates Column N headings and keeps all rows.
Markdown escapes punctuation and uses <br> for cell line breaks; rendered
whitespace and HTML line-break support depend on the receiving renderer.

CSV and JSON input limits: 1,000,000 UTF-16 code units, 10,000 rows,
256 columns. Markdown limits: 100,000 code units, 1,000 rows, 64 columns.
The preview shows up to 30 data rows and 8 columns; complete outputs,
copying and downloads include every parsed row and column.

The page has no uploads, external runtime assets or storage. No server or
installation is needed. Clipboard permissions vary; manual copying and
downloads remain available. Pasting preserves received text; editing the
input uses browser-normalized line endings and requires choosing Parse.

This handles plain CSV/TSV text, not XLSX, HTML tables, styles or merged
cells. It cannot recover values already changed by a source application.
It is a separate browser utility, not a PowerToys action. Native Windows
or Excel clipboard interoperability has not been tested.

Free under the included MIT license. The optional coffee footer in the
tool is never required to use it. Feedback with invented examples is welcome.

Source and guide: https://github.com/tevinch/data-shape-kit/tree/main/javascript/clipboard-table
Report a case: https://github.com/tevinch/data-shape-kit/issues

Copyright (c) 2026 Tevinch
