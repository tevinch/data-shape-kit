# Repeated clock selector correction

This is an unofficial build, not a release by the rrule maintainers.

Source: https://github.com/tevinch/rrule/commit/938435d366cb0e0fbe81f56ca44d045edf2e03c5
Base: https://github.com/jkbrzt/rrule/commit/9f2061febeeb363d03352efe33d30c33073a0242
Report: https://github.com/jkbrzt/rrule/issues/671

Repeated BYHOUR, BYMINUTE and BYSECOND values are removed from internal options before iteration. Original options and serialization are retained. The original COUNT=12 / BYSECOND=0,30,0 set query returns 12 distinct dates through 09:05:30, instead of 8 through 09:03:30.

The upstream source manifest says 2.8.0. Its 28 compiled ESM JavaScript modules match npm 2.8.1 except for this build's parseoptions.js correction. This package uses a distinct prerelease version, 2.8.1-clock-values.0; it is distributed as a tarball, not published to npm.

The source change and its 10 regression cases are included. Full source suite: 391 passed, 9 existing skipped. Type checking, lint, formatting and distribution build passed on Node 18.20.4 / macOS. These are scripted checks, not human manual validation. The correction uses ES5 array operations and does not require Set or Array.from in the library runtime.

This does not address overlapping BYSETPOS selections, existing unsorted selector ordering, time-zone/DST behavior or malformed input validation. Keep the upstream UTC/floating-time conventions.

The original README, author credits and BSD-3-Clause LICENCE are retained. The package manifest's version, description, repository, homepage and included files identify this build; library API entry points and runtime dependency declarations are unchanged.
