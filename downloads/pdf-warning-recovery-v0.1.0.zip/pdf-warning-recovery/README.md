# Keep PDF pages when resources contain duplicate names

**Upstream merged — checked 28 September 2026:** [libcupsfilters PR #254](https://github.com/OpenPrinting/libcupsfilters/pull/254) was merged into `master` on 27 September (UTC). The latest upstream release is still [2.2.1](https://github.com/OpenPrinting/libcupsfilters/releases/tag/2.2.1), which predates this repair; a merge does not establish availability in your distribution's packages. The original reporter [confirmed successful physical printing](https://github.com/OpenPrinting/libcupsfilters/pull/254#issuecomment-5775682101) on Arch Linux with a Canon MF230: both plain and fit-scaled jobs completed, with all pages and repeated images present. This is the reporter's validation of that setup.

This source patch lets libcupsfilters continue when PDFio reports a recoverable warning. It fixes the tested case where repeated references to the same image caused a PDF conversion to return zero pages, or to keep the pages but lose their images.

The problem is tracked in [libcupsfilters #230](https://github.com/OpenPrinting/libcupsfilters/issues/230). PDFio's error callback must return `true` to continue a warning; the affected callback always returned `false`. The patch also forwards warnings and errors through the filter's supplied logger and preserves the requested error-sheet behavior.

Download the [patch and regression checks](../../downloads/pdf-warning-recovery-v0.1.0.zip?raw=true), or read the [unified diff](libcupsfilters-pdfio-warnings.patch). This source patch is supplied for maintainers and package builders working with 2.2.1. It is not an upstream release or an installable replacement package.

## Apply and check

Use a clean libcupsfilters **2.2.1** source tree. The patch was also checked against the pre-merge filter sources at [`c5dc208`](https://github.com/OpenPrinting/libcupsfilters/commit/c5dc208c05068ed2b1428e3562516a4bd08e0f0f). Do not reapply it to a source tree that already includes PR #254.

```sh
cd /path/to/libcupsfilters-2.2.1
patch --dry-run -p1 < /path/to/pdf-warning-recovery/libcupsfilters-pdfio-warnings.patch
patch -p1 < /path/to/pdf-warning-recovery/libcupsfilters-pdfio-warnings.patch
```

Configure the source tree using its [build instructions](https://github.com/OpenPrinting/libcupsfilters/blob/master/INSTALL.md) and your normal dependency paths. The test driver needs the generated `config.h`, a C compiler, CUPS headers/library, PDFio **1.6.5**, and zlib. The rendering checks need Python 3.10+ and Poppler's `pdftoppm` on `PATH`.

From this example's directory:

```sh
sh build-driver.sh /path/to/libcupsfilters-2.2.1 ./filter-check
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python verify.py --driver ./filter-check
```

The driver compiles the real `pdftopdf.c` and `ipp-options.c`, then calls `cfFilterPDFToPDF()` directly. It reads and writes synthetic PDFs only. The test uses a temporary directory and removes it afterward. To use a different Poppler location, add `--pdftoppm /path/to/pdftoppm`.

`build-driver.sh` uses `pkg-config` for PDFio and `cups-config` (or `pkg-config`) for CUPS. You can provide `PDFIO_CFLAGS`, `PDFIO_LIBS`, `CUPS_CFLAGS`, `CUPS_LIBS`, `CC`, `CFLAGS`, `LDFLAGS`, and `CONFIG_DIR` for an existing local dependency build. It does not install libraries or change a printing service. For a normal package build, use the project's usual build and test commands after applying the patch.

## What was checked

The unpatched 2.2.1 conversion returned success with **zero pages** for the two-page cairo fixture shared in the issue. Its fit and two-up paths kept page counts but lost the red images. The patched conversion retained the images: direct copy and selected-page output matched the input pixels, while fit and two-up matched a clean-resource control.

The included independently generated fixture draws the same red image three times on page 1 and twice on page 2. Its checks cover:

- Direct copy, selection of page 2, A4 fit and two-up output, including page counts and rendered pixels.
- Delivery of warning messages to a custom logger with its callback context.
- `job-error-sheet-when=on-error` retaining two pages for a warning, and `always` adding the requested report page with the warning correctly classified.
- A non-PDF header returning failure and reaching the error logger.
- Duplicate names pointing to different objects, with the compatibility limit below checked explicitly.

The regression command fails on unpatched 2.2.1. The patched 2.2.1 and pre-merge `c5dc208` `pdftopdf.c`/`ipp-options.c` sources were checked with PDFio 1.6.5, CUPS 2.3.4 and a targeted native build on macOS arm64. Those local checks do not establish a full `make check` result or physical printer behavior. Other malformed-PDF paths are outside this patch's coverage.

Separately, [jasonvanwyk tested PR commit `ae2f1f4`](https://github.com/OpenPrinting/libcupsfilters/pull/254#issuecomment-5775593915) on Arch Linux with CUPS 2.4.19, cups-filters 2.0.1, PDFio 1.6.5 and Ghostscript 10.07.1. For the original cairo fixture, plain and fit output retained two pages and five image paints; two-up retained one page and all five paints. The Canon raster stage completed without errors. His subsequent physical-print check covered plain and fit jobs through cupsd and the Canon UFR II driver: both completed without the reported processing hang, producing four correct pages in total. Physical two-up printing was not reported.

His test also found that `cupsfilter` removes `LD_LIBRARY_PATH`, so using that wrapper can accidentally test the installed library. The included driver calls the filter function directly and does not install a library or change the printing service. The reporter's fit output had a small horizontal offset also present in unpatched master; this patch does not address that separate layout behavior.

## Conflicting values still need care

PDF dictionaries must not contain duplicate names. In PDFio **1.6.5**, recovery keeps the **first** value; QPDF keeps the **last**. When the duplicate names refer to the same image, the tested content is preserved. When they refer to different images, this patch does **not** provide QPDF-equivalent output: the issue's blue/red example keeps the first, blue object.

The patch leaves that PDFio policy intact and makes its warning visible through the configured logger. It does not correct the PDF producer. Thanks to jbtheou and jasonvanwyk for the reports and synthetic reproductions.

## License

The libcupsfilters patch retains the upstream [Apache 2.0 license with CUPS exceptions](LICENSE) and [notices](NOTICE). The patch changes warning recovery, logging and error-sheet classification in `pdftopdf.c` and its private header. The accompanying driver, build script and regression generator are Copyright 2026 Tevinch and licensed under Apache 2.0.

## Optional coffee

If this saves you some time and you'd like to buy me a coffee, thank you. It's entirely optional; the patch and checks are free.

- **USDC / SOL · Solana:** `9tY6D9mwcFaJwwzEHvw2v7nhSpdjqjNBYtuooyBN6rYy`
- **USDC / ETH · Base:** `0x568Ab98578d682FB0B0b45619BE73EbFfbf5a6eA`
- **USDT · BNB Smart Chain (BEP20):** `0x568Ab98578d682FB0B0b45619BE73EbFfbf5a6eA`
