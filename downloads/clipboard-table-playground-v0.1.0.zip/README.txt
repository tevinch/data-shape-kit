# Clipboard Table — local browser playground v0.1.0

1. Extract this archive.
2. Open index.html in a modern browser with JavaScript enabled.
3. Choose Load example or paste plain, tab-separated spreadsheet text.
4. Use the first-row option for JSON objects with header keys, or turn it off
   for arrays of strings. Choose Download JSON to save the complete result.

No installation, web server, uploads or external runtime assets are needed.
All values remain strings. Quoted multiline cells, doubled quotes, empty
columns and leading-zero strings are preserved in the received plain text.
Pasting replaces the input and retains its line endings. Editing the box
uses the browser's normalized line endings; choose Parse after editing.

The preview shows up to 30 data rows and 8 columns. JSON includes the full
parsed result. Limits are 1,000,000 UTF-16 code units, 10,000 rows and 256
columns. Header keys must be nonblank and unique, and rows must match their
width. With headers off, ragged arrays are preserved.

This reads quoted TSV, not XLSX files or HTML tables. It does not preserve
formatting, merged cells or values already lost in a source application.

Free under the included MIT license. The optional coffee footer in the
example is never required to use the tool.

Source and guide: https://github.com/tevinch/data-shape-kit/tree/main/javascript/clipboard-table
Report a small synthetic case: https://github.com/tevinch/data-shape-kit/issues

Copyright (c) 2026 Tevinch
