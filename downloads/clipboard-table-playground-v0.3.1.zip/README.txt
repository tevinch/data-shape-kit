# Clipboard Table — local browser playground v0.3.1

1. Extract this archive and open index.html in a modern browser with JavaScript.
2. Choose TSV (tabs) or CSV (commas), then Load example or paste table text.
3. Select JSON or Markdown table. Copy the complete output or download a file.
   If automatic copying is unavailable, manually copy the selected output.

No installation, web server, uploads or external runtime assets are needed.
Quoted multiline cells, doubled quotes, empty columns and leading-zero strings
are retained in the received plain text. Pasting replaces the input and keeps
its line endings. Editing uses the browser's normalized line endings; choose
Parse after editing. Changing either format reparses the current input without
rewriting it. Delimiters are explicit, never guessed. CSV uses commas and
requires double quotes around cells containing commas, line breaks or quotes;
double any quote inside a quoted cell. Malformed quoting reports coordinates.
Semicolon CSV, XLSX and file uploads are not supported; paste the text instead.

The preview shows at most 30 data rows and 8 columns. Output, copy and download
include the complete result. JSON limits: 1,000,000 UTF-16 code units, 10,000
rows, 256 columns. Markdown limits: 100,000 code units, 1,000 rows, 64 columns.
Character limits include input delimiters and quotes.

With first-row headers enabled, JSON needs nonblank, unique keys and equal
row widths. With headers off, JSON preserves ragged arrays. Markdown always
needs equal-width rows; headings can be blank or repeated. With headings off,
Markdown generates Column 1, Column 2, etc. and retains all input rows as data.
Markdown escapes punctuation and uses <br> for cell line breaks. Rendered
whitespace and HTML line-break support depend on the Markdown renderer.

Clipboard permissions vary, especially for local files. The full output is
available for manual copying. Downloads use .json or .md as appropriate.
This does not preserve spreadsheet formatting or merged cells, or recover
values already lost in the source application.

Free under the included MIT license. The optional coffee footer is never
required to use the tool. Feedback with a small synthetic case is welcome.

Source: https://github.com/tevinch/data-shape-kit/tree/main/javascript/clipboard-table
Issues: https://github.com/tevinch/data-shape-kit/issues
Copyright (c) 2026 Tevinch
