import { c1 as Rect, aM as Emitter, by as PointerDragEvent, bz as ElementDragging, c2 as DragMetaInput, P as PluginInput } from './chunks/03e73926.js';

declare abstract class ScrollController {
    abstract getScrollTop(): number;
    abstract getScrollLeft(): number;
    abstract setScrollTop(top: number): void;
    abstract setScrollLeft(left: number): void;
    abstract getClientWidth(): number;
    abstract getClientHeight(): number;
    abstract getScrollWidth(): number;
    abstract getScrollHeight(): number;
    getMaxScrollTop(): number;
    getMaxScrollLeft(): number;
    canScrollVertically(): boolean;
    canScrollHorizontally(): boolean;
    canScrollUp(): boolean;
    canScrollDown(): boolean;
    canScrollLeft(): boolean;
    canScrollRight(): boolean;
}

declare abstract class ScrollGeomCache extends ScrollController {
    clientRect: Rect;
    origScrollTop: number;
    origScrollLeft: number;
    protected scrollController: ScrollController;
    protected doesListening: boolean;
    protected scrollTop: number;
    protected scrollLeft: number;
    protected scrollWidth: number;
    protected scrollHeight: number;
    protected clientWidth: number;
    protected clientHeight: number;
    constructor(scrollController: ScrollController, doesListening: boolean);
    abstract getEventTarget(): EventTarget;
    abstract computeClientRect(): Rect;
    destroy(): void;
    handleScroll: () => void;
    getScrollTop(): number;
    getScrollLeft(): number;
    setScrollTop(top: number): void;
    setScrollLeft(top: number): void;
    getClientWidth(): number;
    getClientHeight(): number;
    getScrollWidth(): number;
    getScrollHeight(): number;
    handleScrollChange(): void;
}

declare class PointerDragging {
    containerEl: EventTarget;
    subjectEl: HTMLElement | null;
    emitter: Emitter<any>;
    selector: string;
    handleSelector: string;
    shouldIgnoreMove: boolean;
    shouldWatchScroll: boolean;
    private isDragging;
    private isTouchDragging;
    wasTouchScroll: boolean;
    private origPageX;
    private origPageY;
    private prevPageX;
    private prevPageY;
    private prevScrollX;
    private prevScrollY;
    constructor(containerEl: EventTarget);
    destroy(): void;
    cancel(): void;
    tryStart(ev: UIEvent): boolean;
    cleanup(): void;
    querySubjectEl(ev: UIEvent): HTMLElement;
    handleMouseDown: (ev: MouseEvent) => void;
    handleMouseMove: (ev: MouseEvent) => void;
    handleMouseUp: (ev: MouseEvent) => void;
    shouldIgnoreMouse(): number | boolean;
    handleTouchStart: (ev: TouchEvent) => void;
    handleTouchMove: (ev: TouchEvent) => void;
    handleTouchEnd: (ev: TouchEvent) => void;
    handleTouchScroll: () => void;
    cancelTouchScroll(): void;
    initScrollWatch(ev: PointerDragEvent): void;
    recordCoords(ev: PointerDragEvent): void;
    handleScroll: (ev: UIEvent) => void;
    destroyScrollWatch(): void;
    createEventFromMouse(ev: MouseEvent, isFirst?: boolean): PointerDragEvent;
    createEventFromTouch(ev: TouchEvent, isFirst?: boolean): PointerDragEvent;
}

declare class ElementMirror {
    isVisible: boolean;
    origScreenX?: number;
    origScreenY?: number;
    deltaX?: number;
    deltaY?: number;
    sourceEl: HTMLElement | null;
    mirrorEl: HTMLElement | null;
    sourceElRect: Rect | null;
    parentNode: HTMLElement;
    zIndex: number;
    revertDuration: number;
    colorScheme: string;
    start(sourceEl: HTMLElement, pageX: number, pageY: number): void;
    handleMove(pageX: number, pageY: number): void;
    setIsVisible(bool: boolean): void;
    stop(needsRevertAnimation: boolean, callback: () => void): void;
    doRevertAnimation(callback: () => void, revertDuration: number): void;
    cleanup(): void;
    updateElPosition(): void;
    getMirrorEl(): HTMLElement;
}

declare class AutoScroller {
    isEnabled: boolean;
    scrollQuery: (Window | string)[];
    edgeThreshold: number;
    maxVelocity: number;
    pointerScreenX: number | null;
    pointerScreenY: number | null;
    isAnimating: boolean;
    scrollCaches: ScrollGeomCache[] | null;
    msSinceRequest?: number;
    everMovedUp: boolean;
    everMovedDown: boolean;
    everMovedLeft: boolean;
    everMovedRight: boolean;
    start(pageX: number, pageY: number, scrollStartEl: HTMLElement): void;
    handleMove(pageX: number, pageY: number): void;
    stop(): void;
    requestAnimation(now: number): void;
    private animate;
    private handleSide;
    private computeBestEdge;
    private buildCaches;
    private queryScrollEls;
}

declare class FeaturefulElementDragging extends ElementDragging {
    private containerEl;
    pointer: PointerDragging;
    mirror: ElementMirror;
    autoScroller: AutoScroller;
    delay: number | null;
    minDistance: number;
    touchScrollAllowed: boolean;
    private mirrorNeedsRevert;
    private isInteracting;
    private isDragging;
    private isDelayEnded;
    private isDistanceSurpassed;
    private delayTimeoutId;
    constructor(containerEl: HTMLElement, selector?: string);
    destroy(): void;
    onPointerDown: (ev: PointerDragEvent) => void;
    onPointerMove: (ev: PointerDragEvent) => void;
    onPointerUp: (ev: PointerDragEvent) => void;
    startDelay(ev: PointerDragEvent): void;
    handleDelayEnd(ev: PointerDragEvent): void;
    handleDistanceSurpassed(ev: PointerDragEvent): void;
    tryStartDrag(ev: PointerDragEvent): void;
    tryStopDrag(ev: PointerDragEvent): void;
    stopDrag(ev: PointerDragEvent): void;
    cancel(): void;
    setMirrorIsVisible(bool: boolean): void;
    setMirrorNeedsRevert(bool: boolean): void;
    setAutoScrollEnabled(bool: boolean): void;
}

type DragMetaGenerator = DragMetaInput | ((el: HTMLElement) => DragMetaInput);

declare class InferredElementDragging extends ElementDragging {
    pointer: PointerDragging;
    shouldIgnoreMove: boolean;
    mirrorSelector: string;
    currentMirrorEl: HTMLElement | null;
    constructor(containerEl: HTMLElement);
    destroy(): void;
    handlePointerDown: (ev: PointerDragEvent) => void;
    handlePointerMove: (ev: PointerDragEvent) => void;
    handlePointerUp: (ev: PointerDragEvent) => void;
    cancel(): void;
    setMirrorIsVisible(bool: boolean): void;
}

interface ThirdPartyDraggableSettings {
    eventData?: DragMetaGenerator;
    itemSelector?: string;
    mirrorSelector?: string;
}
declare class ThirdPartyDraggable {
    dragging: InferredElementDragging;
    constructor(containerOrSettings?: EventTarget | ThirdPartyDraggableSettings, settings?: ThirdPartyDraggableSettings);
    destroy(): void;
}

interface ExternalDraggableSettings {
    eventData?: DragMetaGenerator;
    itemSelector?: string;
    minDistance?: number;
    longPressDelay?: number;
    appendTo?: HTMLElement;
}
declare class ExternalDraggable {
    dragging: FeaturefulElementDragging;
    settings: ExternalDraggableSettings;
    constructor(el: HTMLElement, settings?: ExternalDraggableSettings);
    handlePointerDown: (ev: PointerDragEvent) => void;
    handleDragStart: (ev: PointerDragEvent) => void;
    destroy(): void;
}

declare const _default: PluginInput;
//# sourceMappingURL=index.d.ts.map

export { ExternalDraggable as Draggable, ThirdPartyDraggable, _default as default };
