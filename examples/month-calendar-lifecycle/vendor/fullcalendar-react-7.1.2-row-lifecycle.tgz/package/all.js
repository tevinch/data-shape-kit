import { jsx } from 'react/jsx-runtime';
import { C as Calendar$1 } from './chunks/5b402f63.js';
import { i as interactionPlugin } from './chunks/1b93d734.js';
import { d as dayGridPlugin } from './chunks/b3eaf512.js';
import { t as timeGridPlugin } from './chunks/8fd9bde2.js';
import { l as listPlugin } from './chunks/1849f27f.js';
import { m as multiMonthPlugin } from './chunks/1d69bc04.js';

const plugins = [
    interactionPlugin,
    dayGridPlugin,
    timeGridPlugin,
    listPlugin,
    multiMonthPlugin,
];
function Calendar(options = {}) {
    return (jsx(Calendar$1, { ...options, plugins: [
            ...plugins,
            ...(options.plugins || []),
        ] }));
}

export { Calendar, Calendar as default, plugins };
