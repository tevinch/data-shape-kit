import { P as PluginInput } from '../../chunks/03e73926';

declare const _default: PluginInput;
//# sourceMappingURL=index.d.ts.map

export { _default as default };
