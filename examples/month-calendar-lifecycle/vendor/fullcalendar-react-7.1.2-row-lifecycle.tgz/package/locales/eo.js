var l22 = {
    code: 'eo',
    week: {
        dow: 1, // Monday is the first day of the week.
        doy: 4, // The week that contains Jan 4th is the first week of the year.
    },
    prevText: 'Antaŭa',
    nextText: 'Sekva',
    todayText: 'Hodiaŭ',
    yearText: 'Jaro',
    monthText: 'Monato',
    weekTextLong: 'Semajno',
    weekTextShort: 'Sm',
    dayText: 'Tago',
    listText: 'Tagordo',
    allDayText: 'Tuta\ntago',
    moreLinkText: 'pli',
    noEventsText: 'Neniuj eventoj por montri',
};

export { l22 as default };
