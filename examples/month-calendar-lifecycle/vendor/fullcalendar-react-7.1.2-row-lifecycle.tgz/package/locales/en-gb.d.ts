import { L as LocaleInput } from '../chunks/03e73926';

declare const _default: LocaleInput;
//# sourceMappingURL=en-gb.d.ts.map

export { _default as default };
