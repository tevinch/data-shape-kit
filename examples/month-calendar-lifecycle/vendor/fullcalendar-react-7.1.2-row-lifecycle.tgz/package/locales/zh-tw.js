var l78 = {
    code: 'zh-tw',
    prevText: '上個',
    nextText: '下個',
    todayText: '今天',
    yearText: '年',
    monthText: '月',
    weekTextLong: '週',
    dayText: '天',
    listText: '活動列表',
    allDayText: '整天',
    moreLinkText: '顯示更多',
    noEventsText: '沒有任何活動',
};

export { l78 as default };
