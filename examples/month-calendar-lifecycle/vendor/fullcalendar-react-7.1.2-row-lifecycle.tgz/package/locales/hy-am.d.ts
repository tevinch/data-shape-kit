import { L as LocaleInput } from '../chunks/03e73926';

declare const _default: LocaleInput;
//# sourceMappingURL=hy-am.d.ts.map

export { _default as default };
