var l33 = {
    code: 'he',
    direction: 'rtl',
    prevText: 'הקודם',
    nextText: 'הבא',
    todayText: 'היום',
    yearText: 'שנה',
    monthText: 'חודש',
    weekTextLong: 'שבוע',
    dayText: 'יום',
    listText: 'סדר יום',
    allDayText: 'כל היום',
    moreLinkText: 'נוספים',
    noEventsText: 'אין אירועים להצגה',
};

export { l33 as default };
