import { L as LocaleInput } from '../chunks/03e73926';

declare const _default: LocaleInput;
//# sourceMappingURL=el.d.ts.map

export { _default as default };
