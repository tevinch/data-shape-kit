export { t as default } from './chunks/8fd9bde2.js';
