export { l as default } from './chunks/1849f27f.js';
