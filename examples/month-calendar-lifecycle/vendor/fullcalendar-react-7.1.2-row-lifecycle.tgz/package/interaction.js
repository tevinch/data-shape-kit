import { b as buildDatePointApiWithContext, H as HitDragging, P as PointerDragging, F as FeaturefulElementDragging } from './chunks/1b93d734.js';
export { i as default } from './chunks/1b93d734.js';
import { i as interactionSettingsStore } from './chunks/a924306d.js';
import { r as refineProps, n as createEmptyEventStore, A as eventTupleToStore, a3 as enableCursor, a4 as disableCursor, z as EventImpl, ay as refineEventDef, az as parseEventDef, aA as addDurationToEdge, aB as getDefaultEventEndEdge, aC as createEventInstance, R as buildEventInstanceRange, B as BASE_OPTION_DEFAULTS } from './chunks/6e87ff0f.js';
import { a as isInteractionValid, c as config, E as ElementDragging } from './chunks/1cd0767d.js';
import { createDuration } from '@full-ui/headless-calendar';
import { c as classNames } from './chunks/e8f6e367.js';

/*
Information about what will happen when an external element is dragged-and-dropped
onto a calendar. Contains information for creating an event.
*/
const DRAG_META_REFINERS = {
    startTime: createDuration,
    duration: createDuration,
    create: Boolean,
    sourceId: String,
};
function parseDragMeta(raw) {
    let { refined, extra } = refineProps(raw, DRAG_META_REFINERS);
    return {
        startTime: refined.startTime || null,
        duration: refined.duration || null,
        create: refined.create != null ? refined.create : true,
        sourceId: refined.sourceId,
        leftoverProps: extra,
    };
}

/*
Given an already instantiated draggable object for one-or-more elements,
Interprets any dragging as an attempt to drag an events that lives outside
of a calendar onto a calendar.
*/
class ExternalElementDragging {
    constructor(dragging, suppliedDragMeta) {
        this.receivingContext = null;
        this.droppableEvent = null; // will exist for all drags, even if create:false
        this.suppliedDragMeta = null;
        this.dragMeta = null;
        this.handleDragStart = (ev) => {
            this.dragMeta = this.buildDragMeta(ev.subjectEl);
        };
        this.handleHitUpdate = (hit, isFinal, ev) => {
            let { dragging } = this.hitDragging;
            let receivingContext = null;
            let droppableEvent = null;
            let isInvalid = false;
            let interaction = {
                affectedEvents: createEmptyEventStore(),
                mutatedEvents: createEmptyEventStore(),
                isEvent: this.dragMeta.create,
            };
            if (hit) {
                receivingContext = hit.context;
                if (this.canDropElOnCalendar(ev.subjectEl, receivingContext)) {
                    droppableEvent = computeEventForDateSpan(hit.dateSpan, this.dragMeta, receivingContext);
                    interaction.mutatedEvents = eventTupleToStore(droppableEvent);
                    isInvalid = !isInteractionValid(interaction, hit.dateProfile, receivingContext);
                    if (isInvalid) {
                        interaction.mutatedEvents = createEmptyEventStore();
                        droppableEvent = null;
                    }
                }
            }
            this.displayDrag(receivingContext, interaction);
            // show mirror if no already-rendered mirror element OR if we are shutting down the mirror (?)
            // TODO: wish we could somehow wait for dispatch to guarantee render
            dragging.setMirrorIsVisible(isFinal ||
                !droppableEvent ||
                !document.querySelector(`.${classNames.internalEventMirror}`));
            if (!isInvalid) {
                enableCursor();
            }
            else {
                disableCursor();
            }
            if (!isFinal) {
                dragging.setMirrorNeedsRevert(!droppableEvent);
                this.receivingContext = receivingContext;
                this.droppableEvent = droppableEvent;
            }
        };
        this.handleDragEnd = (pev) => {
            let { receivingContext, droppableEvent } = this;
            this.clearDrag();
            if (receivingContext && droppableEvent) {
                let finalHit = this.hitDragging.finalHit;
                let finalView = finalHit.context.viewApi;
                let dragMeta = this.dragMeta;
                receivingContext.emitter.trigger('drop', {
                    ...buildDatePointApiWithContext(finalHit.dateSpan, receivingContext),
                    draggedEl: pev.subjectEl,
                    jsEvent: pev.origEvent, // Is this always a mouse event? See #4655
                    view: finalView,
                });
                if (dragMeta.create) {
                    let addingEvents = eventTupleToStore(droppableEvent);
                    receivingContext.dispatch({
                        type: 'MERGE_EVENTS',
                        eventStore: addingEvents,
                    });
                    if (pev.isTouch) {
                        receivingContext.dispatch({
                            type: 'SELECT_EVENT',
                            eventInstanceId: droppableEvent.instance.instanceId,
                        });
                    }
                    // signal that an external event landed
                    receivingContext.emitter.trigger('eventReceive', {
                        event: new EventImpl(receivingContext, droppableEvent.def, droppableEvent.instance),
                        relatedEvents: [],
                        revert() {
                            receivingContext.dispatch({
                                type: 'REMOVE_EVENTS',
                                eventStore: addingEvents,
                            });
                        },
                        draggedEl: pev.subjectEl,
                        view: finalView,
                    });
                }
            }
            this.receivingContext = null;
            this.droppableEvent = null;
        };
        let hitDragging = this.hitDragging = new HitDragging(dragging, interactionSettingsStore);
        hitDragging.requireInitial = false; // will start outside of a component
        hitDragging.emitter.on('dragstart', this.handleDragStart);
        hitDragging.emitter.on('hitupdate', this.handleHitUpdate);
        hitDragging.emitter.on('dragend', this.handleDragEnd);
        this.suppliedDragMeta = suppliedDragMeta;
    }
    buildDragMeta(subjectEl) {
        if (typeof this.suppliedDragMeta === 'object') {
            return parseDragMeta(this.suppliedDragMeta);
        }
        if (typeof this.suppliedDragMeta === 'function') {
            return parseDragMeta(this.suppliedDragMeta(subjectEl));
        }
        return getDragMetaFromEl(subjectEl);
    }
    displayDrag(nextContext, state) {
        let prevContext = this.receivingContext;
        if (prevContext && prevContext !== nextContext) {
            prevContext.dispatch({ type: 'UNSET_EVENT_DRAG' });
        }
        if (nextContext) {
            nextContext.dispatch({ type: 'SET_EVENT_DRAG', state });
        }
    }
    clearDrag() {
        if (this.receivingContext) {
            this.receivingContext.dispatch({ type: 'UNSET_EVENT_DRAG' });
        }
    }
    canDropElOnCalendar(el, receivingContext) {
        let dropAccept = receivingContext.options.dropAccept;
        if (typeof dropAccept === 'function') {
            return dropAccept.call(receivingContext.calendarApi, el);
        }
        if (typeof dropAccept === 'string' && dropAccept) {
            return el.matches(dropAccept);
        }
        return true;
    }
}
// Utils for computing event store from the DragMeta
// ----------------------------------------------------------------------------------------------------
function computeEventForDateSpan(dateSpan, dragMeta, context) {
    let defProps = { ...dragMeta.leftoverProps };
    for (let transform of context.pluginHooks.externalDefTransforms) {
        Object.assign(defProps, transform(dateSpan, dragMeta));
    }
    let { refined, extra } = refineEventDef(defProps, context);
    let def = parseEventDef(refined, extra, dragMeta.sourceId, dateSpan.allDay, context.options.forceEventDuration || Boolean(dragMeta.duration), // hasEnd
    context);
    let start = dateSpan.range.start;
    // only rely on time info if drop zone is all-day,
    // otherwise, we already know the time
    if (dateSpan.allDay && dragMeta.startTime) {
        start = context.dateEnv.add(start, dragMeta.startTime);
    }
    // carry the drop span's exact instant when the start marker was used as-is
    // (keeps identity during DST fall-back doubled slots)
    let startEdge = {
        marker: start,
        instantMs: !dateSpan.allDay ? dateSpan.instantStartMs : undefined,
    };
    // an exact start yields an exact derived end (real elapsed duration)
    let endEdge = dragMeta.duration ?
        addDurationToEdge(startEdge, dragMeta.duration, context.dateEnv) :
        getDefaultEventEndEdge(dateSpan.allDay, startEdge, context);
    let instance = createEventInstance(def.defId, buildEventInstanceRange(startEdge.marker, endEdge.marker, startEdge.instantMs, endEdge.instantMs));
    return { def, instance };
}
// Utils for extracting data from element
// ----------------------------------------------------------------------------------------------------
function getDragMetaFromEl(el) {
    let str = getEmbeddedElData(el, 'event');
    let obj = str ?
        JSON.parse(str) :
        { create: false }; // if no embedded data, assume no event creation
    return parseDragMeta(obj);
}
config.dataAttrPrefix = '';
function getEmbeddedElData(el, name) {
    let prefix = config.dataAttrPrefix;
    let prefixedName = (prefix ? prefix + '-' : '') + name;
    return el.getAttribute('data-' + prefixedName) || '';
}

/*
Detects when a *THIRD-PARTY* drag-n-drop system interacts with elements.
The third-party system is responsible for drawing the visuals effects of the drag.
This class simply monitors for pointer movements and fires events.
It also has the ability to hide the moving element (the "mirror") during the drag.
*/
class InferredElementDragging extends ElementDragging {
    constructor(containerEl) {
        super(containerEl);
        this.shouldIgnoreMove = false;
        this.mirrorSelector = '';
        this.currentMirrorEl = null;
        this.handlePointerDown = (ev) => {
            this.emitter.trigger('pointerdown', ev);
            if (!this.shouldIgnoreMove) {
                // fire dragstart right away. does not support delay or min-distance
                this.emitter.trigger('dragstart', ev);
            }
        };
        this.handlePointerMove = (ev) => {
            if (!this.shouldIgnoreMove) {
                this.emitter.trigger('dragmove', ev);
            }
        };
        this.handlePointerUp = (ev) => {
            this.emitter.trigger('pointerup', ev);
            if (!this.shouldIgnoreMove) {
                // fire dragend right away. does not support a revert animation
                this.emitter.trigger('dragend', ev);
            }
        };
        let pointer = this.pointer = new PointerDragging(containerEl);
        pointer.emitter.on('pointerdown', this.handlePointerDown);
        pointer.emitter.on('pointermove', this.handlePointerMove);
        pointer.emitter.on('pointerup', this.handlePointerUp);
    }
    destroy() {
        this.pointer.destroy();
    }
    cancel() {
        this.shouldIgnoreMove = true;
    }
    setMirrorIsVisible(bool) {
        if (bool) {
            // restore a previously hidden element.
            // use the reference in case the selector class has already been removed.
            if (this.currentMirrorEl) {
                this.currentMirrorEl.style.visibility = '';
                this.currentMirrorEl = null;
            }
        }
        else {
            let mirrorEl = this.mirrorSelector
                // TODO: somehow query FullCalendars WITHIN shadow-roots
                ? document.querySelector(this.mirrorSelector)
                : null;
            if (mirrorEl) {
                this.currentMirrorEl = mirrorEl;
                mirrorEl.style.visibility = 'hidden';
            }
        }
    }
}

/*
Bridges third-party drag-n-drop systems with FullCalendar.
Must be instantiated and destroyed by caller.
*/
class ThirdPartyDraggable {
    constructor(containerOrSettings, settings) {
        let containerEl = document;
        if (
        // wish we could just test instanceof EventTarget, but doesn't work in IE11
        containerOrSettings === document ||
            containerOrSettings instanceof Element) {
            containerEl = containerOrSettings;
            settings = settings || {};
        }
        else {
            settings = (containerOrSettings || {});
        }
        let dragging = this.dragging = new InferredElementDragging(containerEl);
        if (typeof settings.itemSelector === 'string') {
            dragging.pointer.selector = settings.itemSelector;
        }
        else if (containerEl === document) {
            dragging.pointer.selector = '[data-event]';
        }
        if (typeof settings.mirrorSelector === 'string') {
            dragging.mirrorSelector = settings.mirrorSelector;
        }
        let externalDragging = new ExternalElementDragging(dragging, settings.eventData);
        // The hit-detection system requires that the dnd-mirror-element be pointer-events:none,
        // but this can't be guaranteed for third-party draggables, so disable
        externalDragging.hitDragging.disablePointCheck = true;
    }
    destroy() {
        this.dragging.destroy();
    }
}

/*
Makes an element (that is *external* to any calendar) draggable.
Can pass in data that determines how an event will be created when dropped onto a calendar.
Leverages FullCalendar's internal drag-n-drop functionality WITHOUT a third-party drag system.
*/
class ExternalDraggable {
    constructor(el, settings = {}) {
        this.handlePointerDown = (ev) => {
            let { dragging } = this;
            let { minDistance, longPressDelay } = this.settings;
            dragging.minDistance =
                minDistance != null ?
                    minDistance :
                    (ev.isTouch ? 0 : BASE_OPTION_DEFAULTS.eventDragMinDistance);
            dragging.delay =
                ev.isTouch ? // TODO: eventually read eventLongPressDelay instead vvv
                    (longPressDelay != null ? longPressDelay : BASE_OPTION_DEFAULTS.longPressDelay) :
                    0;
        };
        this.handleDragStart = (ev) => {
            if (ev.isTouch &&
                this.dragging.delay &&
                ev.subjectEl.classList.contains(classNames.internalEvent)) {
                this.dragging.mirror.getMirrorEl().classList.add(classNames.internalEventSelected);
            }
        };
        this.settings = settings;
        let dragging = this.dragging = new FeaturefulElementDragging(el);
        dragging.touchScrollAllowed = false;
        if (settings.itemSelector != null) {
            dragging.pointer.selector = settings.itemSelector;
        }
        if (settings.appendTo != null) {
            dragging.mirror.parentNode = settings.appendTo; // TODO: write tests
        }
        dragging.emitter.on('pointerdown', this.handlePointerDown);
        dragging.emitter.on('dragstart', this.handleDragStart);
        new ExternalElementDragging(dragging, settings.eventData); // eslint-disable-line no-new
    }
    destroy() {
        this.dragging.destroy();
    }
}

export { ExternalDraggable as Draggable, ThirdPartyDraggable };
