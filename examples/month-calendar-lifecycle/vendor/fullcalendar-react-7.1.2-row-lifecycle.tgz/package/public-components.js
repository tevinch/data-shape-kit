export { C as Calendar } from './chunks/5b402f63.js';
