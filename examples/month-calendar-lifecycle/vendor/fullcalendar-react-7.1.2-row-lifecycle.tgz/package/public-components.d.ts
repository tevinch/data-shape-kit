export { C as Calendar, a as CalendarRef } from './chunks/4869bc36.js';
