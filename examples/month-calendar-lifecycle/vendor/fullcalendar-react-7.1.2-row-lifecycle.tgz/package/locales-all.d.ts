import { L as LocaleInput } from './chunks/03e73926.js';

declare const allLocales: LocaleInput[];
//# sourceMappingURL=locales-all.d.ts.map

export { allLocales as default };
