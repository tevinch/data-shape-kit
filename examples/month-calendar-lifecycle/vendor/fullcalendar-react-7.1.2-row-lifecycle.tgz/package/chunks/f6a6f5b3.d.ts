import { aH as Dictionary } from './03e73926.js';

declare class JsonRequestError extends Error {
    response: Response;
    constructor(message: string, response: Response);
}
declare function requestJson<ParsedResponse>(method: string, url: string, params: Dictionary): Promise<[ParsedResponse, Response]>;

export { JsonRequestError as J, requestJson as r };
