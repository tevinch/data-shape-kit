import { FunctionComponent, PropsWithoutRef, Ref } from 'react';
import { a as CalendarApi, d as CalendarOptions } from './03e73926.js';

interface CalendarRef {
    getApi(): CalendarApi;
}
type CalendarPropsInternal = CalendarOptions & {
    id?: string;
};
type CalendarProps = PropsWithoutRef<CalendarPropsInternal> & {
    ref?: Ref<CalendarRef>;
};
declare const Calendar: FunctionComponent<CalendarProps>;

export { Calendar as C, CalendarRef as a };
