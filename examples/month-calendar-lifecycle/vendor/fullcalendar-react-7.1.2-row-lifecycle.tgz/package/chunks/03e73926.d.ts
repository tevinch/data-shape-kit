import { RawOptionsFromRefiners, RefinedOptionsFromRefiners, EventSourceOptions, EventSourceOptionsRefined, BaseOptionsRefined, EventRefiners, BaseOptions } from '@fullcalendar/core/protected-api';
import { NativeDateFormatterOptions, FuncDateFormatterFunc, DateFormatter, DateRange, DateEnv, DateMarker, Duration, DateInput, DateTimeFormatPartWithWeek as DateTimeFormatPartWithWeek$1, DurationInput, DateRangeInput, OpenDateRange, createDuration, CmdDateFormatterFunc, WeekNumberCalculation, LocaleCodeArg } from '@full-ui/headless-calendar';
import * as react_jsx_runtime from 'react/jsx-runtime';
import * as react from 'react';
import { ReactNode, Ref, Component, CSSProperties, ComponentType, FC, RefObject, ReactElement } from 'react';

type FormatterInput = NativeDateFormatterOptions | string | FuncDateFormatterFunc;
declare function createFormatter(input: FormatterInput): DateFormatter;

interface PointerDragEvent {
    origEvent: UIEvent;
    isTouch: boolean;
    subjectEl: EventTarget;
    pageX: number;
    pageY: number;
    deltaX: number;
    deltaY: number;
}

interface EventInstanceRange extends DateRange {
    instantStartMs?: number;
    instantEndMs?: number;
}
interface EventRangeEdge {
    marker: Date;
    instantMs?: number;
}
declare function getRangeInstantStartMs(range: EventInstanceRange, dateEnv: DateEnv): number;
declare function getRangeInstantEndMs(range: EventInstanceRange, dateEnv: DateEnv): number;
declare function buildValidInstanceRange(start: EventRangeEdge, end: EventRangeEdge, dateEnv: DateEnv): EventInstanceRange | null;
interface EventInstance {
    instanceId: string;
    defId: string;
    range: EventInstanceRange;
}
type EventInstanceHash = {
    [instanceId: string]: EventInstance;
};

declare function guid(): string;
interface OrderSpec<Subject> {
    field?: string;
    order?: number;
    func?: FieldSpecInputFunc<Subject>;
}
type FieldSpecInput<Subject> = string | string[] | FieldSpecInputFunc<Subject> | FieldSpecInputFunc<Subject>[];
type FieldSpecInputFunc<Subject> = (a: Subject, b: Subject) => number;
declare function parseFieldSpecs<Subject>(input: FieldSpecInput<Subject>): OrderSpec<Subject>[];
declare function compareByFieldSpecs<Subject>(obj0: Subject, obj1: Subject, fieldSpecs: OrderSpec<Subject>[]): number;
declare function flexibleCompare(a: any, b: any): number;
declare function valuesIdentical<T>(a: T, b: T): boolean;
declare function computeViewBorderless(options: CalendarOptions): {
    borderlessX: boolean;
    borderlessTop: boolean;
    borderlessBottom: boolean;
};

interface ViewApi {
    calendar: CalendarApi;
    type: string;
    title: string;
    activeStart: Date;
    activeEnd: Date;
    currentStart: Date;
    currentEnd: Date;
    getOption(name: string): any;
}

interface EventSourceApi {
    id: string;
    url: string;
    format: string;
    remove(): void;
    refetch(): void;
}

type BusinessHoursInput = boolean | EventInput | EventInput[];
declare function parseBusinessHours(input: BusinessHoursInput, context: CalendarContext): EventStore;

interface Point {
    left: number;
    top: number;
}
interface Rect {
    left: number;
    right: number;
    top: number;
    bottom: number;
}
declare function getRectCenter(rect: Rect): Point;

type MountInfo<DisplayInfo> = DisplayInfo & {
    el: HTMLElement;
};
type DidMountHandler<DisplayInfo> = (mountData: MountInfo<DisplayInfo>) => void;
type WillUnmountHandler<DisplayInfo> = (mountData: MountInfo<DisplayInfo>) => void;
interface ObjCustomContent {
    html?: string;
    domNodes?: any[];
}
type CustomContent = ReactNode | ObjCustomContent;
type ContentGenerator<RenderProps> = CustomContent | ((renderProps: RenderProps) => (CustomContent | true | void | undefined));
type ClassNameInput = string | undefined | null | false | 0;
type ClassNameGenerator<RenderProps> = ClassNameInput | ((renderProps: RenderProps) => ClassNameInput);
declare function refineClassName(input: unknown, optionName: string): ClassNameInput;
declare function refineClassNameGenerator<RenderProps>(input: ClassNameGenerator<RenderProps>, optionName: string): ClassNameGenerator<RenderProps>;

interface EventInteractionState {
    affectedEvents: EventStore;
    mutatedEvents: EventStore;
    isEvent: boolean;
}

interface SplittableProps {
    businessHours: EventStore | null;
    dateSelection: DateSpan | null;
    eventStore: EventStore;
    eventUiBases: EventUiHash;
    eventDrag: EventInteractionState | null;
    eventResize: EventInteractionState | null;
    eventSelection: string;
}
declare abstract class Splitter<PropsType extends SplittableProps = SplittableProps> {
    private getKeysForEventDefs;
    private splitDateSelection;
    private splitEventStore;
    private splitIndividualUi;
    private splitEventDrag;
    private splitEventResize;
    private eventUiBuilders;
    abstract getKeyInfo(props: PropsType): {
        [key: string]: {
            ui?: EventUi;
            businessHours?: EventStore;
        };
    };
    abstract getKeysForDateSpan(dateSpan: DateSpan): string[];
    abstract getKeysForEventDef(eventDef: EventDef): string[];
    splitProps(props: PropsType): {
        [key: string]: SplittableProps;
    };
    private _splitDateSpan;
    private _getKeysForEventDefs;
    private _splitEventStore;
    private _splitIndividualUi;
    private _splitInteraction;
}

interface DateMeta {
    dow: number;
    date: Date;
    isDisabled: boolean;
    isOther: boolean;
    isToday: boolean;
    isPast: boolean;
    isFuture: boolean;
}
declare function getDateMeta(dateMarker: DateMarker, dateEnv: DateEnv, dateProfile?: DateProfile, todayRange?: DateRange, nowDate?: DateMarker): DateMeta;

type EventSourceSuccessResponseHandler = (this: CalendarApiImpl, rawData: any, response: any) => EventInput[] | void;
type EventSourceErrorResponseHandler = (error: Error) => void;
interface EventSource<Meta> {
    _raw: any;
    sourceId: string;
    sourceDefId: number;
    meta: Meta;
    publicId: string;
    isFetching: boolean;
    latestFetchId: string;
    fetchRange: DateRange | null;
    defaultAllDay: boolean | null;
    eventDataTransform: EventInputTransformer;
    ui: EventUi;
    success: EventSourceSuccessResponseHandler | null;
    failure: EventSourceErrorResponseHandler | null;
    extendedProps: Dictionary;
}
type EventSourceHash = {
    [sourceId: string]: EventSource<any>;
};
interface EventSourceFetcherRes {
    rawEvents: EventInput[];
    response?: Response;
}
type EventSourceFetcher<Meta> = (data: {
    eventSource: EventSource<Meta>;
    range: DateRange;
    isRefetch: boolean;
    context: CalendarContext;
}, successCallback: (res: EventSourceFetcherRes) => void, errorCallback: (error: Error) => void) => void;

type EqualityFunc<T> = (a: T, b: T) => boolean;
type EqualityFuncs<P> = {
    [K in keyof P]?: EqualityFunc<P[K]>;
};
declare abstract class PureComponent<Props = Dictionary, State = Dictionary> extends Component<Props, State> {
    static addPropsEquality: typeof addPropsEquality;
    static addStateEquality: typeof addStateEquality;
    static contextType: any;
    context: ViewContext;
    propEquality: EqualityFuncs<Props>;
    stateEquality: EqualityFuncs<State>;
    shouldComponentUpdate(nextProps: Props, nextState: State): boolean;
}
declare abstract class BaseComponent<Props = Dictionary, State = Dictionary> extends PureComponent<Props, State> {
    static contextType: any;
    context: ViewContext;
}
declare function addPropsEquality(this: {
    prototype: {
        propEquality: any;
    };
}, propEquality: any): void;
declare function addStateEquality(this: {
    prototype: {
        stateEquality: any;
    };
}, stateEquality: any): void;
declare function setRef<RefType>(ref: Ref<RefType> | void, current: RefType): void;

type ElRef = Ref<HTMLElement>;
type ElAttrs = {
    ref?: ElRef;
} & Record<string, any>;
interface ElAttrsProps {
    attrs?: ElAttrs;
    className?: string;
    style?: CSSProperties & Record<string, any>;
    elRef?: ElRef;
}
interface ElProps extends ElAttrsProps {
    tag: string;
}
interface ContentGeneratorProps<RenderProps> {
    renderProps: RenderProps;
    generatorName: string | undefined;
    customGenerator?: ContentGenerator<RenderProps>;
    defaultGenerator?: (renderProps: RenderProps) => ReactNode;
}
type ContentInjectorProps<RenderProps> = ElProps & ContentGeneratorProps<RenderProps> & {
    renderId: number;
};
declare class ContentInjector<RenderProps> extends BaseComponent<ContentInjectorProps<RenderProps>> {
    private el;
    private id;
    private queuedDomNodes;
    private currentDomNodes;
    private currentGeneratorMeta;
    render(): react.DetailedReactHTMLElement<react.HTMLAttributes<HTMLElement>, HTMLElement>;
    componentDidMount(): void;
    componentDidUpdate(): void;
    componentWillUnmount(): void;
    private triggerCustomRendering;
    private handleEl;
    private applyQueueudDomNodes;
}

interface ToolbarModel {
    sectionWidgets: {
        start: ToolbarWidget[][];
        center: ToolbarWidget[][];
        end: ToolbarWidget[][];
    };
    viewsWithButtons: string[];
    hasTitle: boolean;
}
interface ToolbarInfo {
    borderlessX: boolean;
    borderlessTop: boolean;
    borderlessBottom: boolean;
}
interface ToolbarSectionInfo {
    name: string;
}
interface ButtonGroupInfo {
    hasSelection: boolean;
}
interface ButtonInfo {
    name: string;
    text: string;
    isPrimary: boolean;
    isSelected: boolean;
    isDisabled: boolean;
    isIconOnly: boolean;
    buttonGroup: ButtonGroupInfo | null;
}
type ButtonDisplay = 'auto' | 'icon' | 'text' | 'icon-text' | 'text-icon';
interface ButtonInput {
    didMount?: DidMountHandler<ButtonInfo>;
    willUnmount?: WillUnmountHandler<ButtonInfo>;
    click?: (ev: MouseEvent) => void;
    hint?: string | ((viewOrCurrentUnitText: string, viewOrCurrentUnit: string) => string);
    class?: ClassNameGenerator<ButtonInfo>;
    className?: ClassNameGenerator<ButtonInfo>;
    display?: ButtonDisplay;
    iconClass?: string | undefined;
    iconContent?: ContentGenerator<{}>;
    text?: string;
    isPrimary?: boolean;
}
interface ToolbarWidget {
    name: string;
    isView?: boolean;
    customElement?: ToolbarElementInput;
    buttonText?: string;
    buttonHint?: string | ((currentUnit: string) => string);
    buttonDisplay?: ButtonDisplay;
    buttonIconClass?: string | undefined;
    buttonIconContent?: ContentGenerator<{}>;
    buttonClick?: (ev: MouseEvent) => void;
    buttonIsPrimary?: boolean;
    buttonClass?: ClassNameGenerator<ButtonInfo>;
    buttonDidMount?: DidMountHandler<ButtonInfo>;
    buttonWillUnmount?: WillUnmountHandler<ButtonInfo>;
}
interface ToolbarInput {
    left?: string;
    center?: string;
    right?: string;
    start?: string;
    end?: string;
}
type ToolbarElementInput = ContentGenerator<{}>;

interface ViewContainerProps extends Partial<ElProps> {
    viewSpec: ViewSpec;
    attrs?: any;
    children?: ReactNode;
}
interface ViewDisplayInfo {
    view: ViewApi;
    borderlessX: boolean;
    borderlessTop: boolean;
    borderlessBottom: boolean;
    options: {
        headerToolbar: ToolbarInput | false | undefined;
        footerToolbar: ToolbarInput | false | undefined;
    };
    isHeightAuto: boolean;
}
declare class ViewContainer extends BaseComponent<ViewContainerProps> {
    private refineRenderProps;
    render(): react_jsx_runtime.JSX.Element;
}

interface ViewProps {
    className?: string;
    dateProfile: DateProfile;
    businessHours: EventStore;
    eventStore: EventStore;
    eventUiBases: EventUiHash;
    dateSelection: DateSpan | null;
    eventSelection: string;
    eventDrag: EventInteractionState | null;
    eventResize: EventInteractionState | null;
    forPrint: boolean;
    labelId: string | undefined;
    labelStr: string | undefined;
}
type ViewContentInfo = ViewProps & ViewDisplayInfo & {
    nextDayThreshold: Duration;
};
declare function sliceEvents(props: ViewContentInfo, allDay?: boolean): EventRenderRange[];

type ViewComponentType = ComponentType<ViewProps>;
type ViewConfigInput = ViewComponentType | ViewOptions;
type ViewConfigInputHash = {
    [viewType: string]: ViewConfigInput;
};

interface ViewSpec {
    type: string;
    component: ViewComponentType;
    duration: Duration;
    durationUnit: string;
    singleUnit: string;
    optionDefaults: ViewOptions;
    optionOverrides: ViewOptions;
}
type ViewSpecHash = {
    [viewType: string]: ViewSpec;
};

interface HandlerFuncTypeHash {
    [eventName: string]: (...args: any[]) => any;
}
declare class Emitter<HandlerFuncs extends HandlerFuncTypeHash> {
    private handlers;
    private options;
    private thisContext;
    setThisContext(thisContext: any): void;
    setOptions(options: Partial<HandlerFuncs>): void;
    on<Prop extends keyof HandlerFuncs>(type: Prop, handler: HandlerFuncs[Prop]): void;
    off<Prop extends keyof HandlerFuncs>(type: Prop, handler?: HandlerFuncs[Prop]): void;
    trigger<Prop extends keyof HandlerFuncs>(type: Prop, ...args: Parameters<HandlerFuncs[Prop]>): void;
    hasHandlers(type: keyof HandlerFuncs): boolean;
}

declare class CalendarNowManager {
    private dateEnv?;
    private resetListeners;
    private nowAnchorDate?;
    private nowAnchorQueried?;
    private nowFn?;
    handleInput(dateEnv: DateEnv, // will change if timezone setup changed
    nowInput: DateInput | (() => DateInput)): void;
    getDateMarker(): DateMarker;
    getEpochMs(): number;
    addResetListener(handler: () => void): void;
    removeResetListener(handler: () => void): void;
}

interface CalendarDataManagerState {
    dynamicOptionOverrides: CalendarOptions;
    currentViewType: string;
    currentDate: DateMarker;
    dateProfile: DateProfile;
    businessHours: EventStore;
    eventSources: EventSourceHash;
    eventUiBases: EventUiHash;
    eventStore: EventStore;
    renderableEventStore: EventStore;
    dateSelection: DateSpan | null;
    eventSelection: string;
    eventDrag: EventInteractionState | null;
    eventResize: EventInteractionState | null;
    selectionConfig: EventUi;
    nowDate: DateMarker;
}
interface CalendarToolbarProps {
    title: string;
    selectedButton: string;
    navUnit: string;
    isTodayEnabled: boolean;
    isPrevEnabled: boolean;
    isNextEnabled: boolean;
}
interface CalendarOptionsData {
    localeDefaults: CalendarOptions;
    calendarOptions: CalendarOptionsRefined;
    toolbarConfig: {
        [toolbarName: string]: ToolbarModel;
    };
    availableRawLocales: any;
    dateEnv: DateEnv;
    pluginHooks: PluginHooks;
    viewSpecs: ViewSpecHash;
}
interface CalendarCurrentViewData {
    viewSpec: ViewSpec;
    options: ViewOptionsRefined;
    viewApi: ViewImpl;
    dateProfileGenerator: DateProfileGenerator;
}
type CalendarDataBase = CalendarOptionsData & CalendarCurrentViewData & CalendarDataManagerState;
interface CalendarData extends CalendarDataBase {
    nowManager: CalendarNowManager;
    viewTitle: string;
    calendarApi: CalendarApiImpl;
    dispatch: (action: Action) => void;
    emitter: Emitter<Required<CalendarListeners>>;
    getCurrentData(): CalendarData;
    toolbarProps: CalendarToolbarProps;
}

declare class ViewImpl implements ViewApi {
    type: string;
    private getCurrentData;
    private dateEnv;
    constructor(type: string, getCurrentData: () => CalendarData, dateEnv: DateEnv);
    get calendar(): CalendarApi;
    get title(): string;
    get activeStart(): Date;
    get activeEnd(): Date;
    get currentStart(): Date;
    get currentEnd(): Date;
    getOption(name: string): any;
}

interface Hit {
    componentId?: string;
    context?: ViewContext;
    dateProfile: DateProfile;
    dateSpan: DateSpan;
    getDayEl: () => HTMLElement;
    rect: Rect;
    layer: number;
    largeUnit?: string;
}

interface EventSegUiInteractionState<S> {
    affectedInstances: EventInstanceHash;
    segs: (S & EventRangeProps)[];
    isEvent: boolean;
}
declare abstract class DateComponent<Props = Dictionary, State = Dictionary> extends BaseComponent<Props, State> {
    uid: string;
    prepareHits(): void;
    queryHit(isRtl: boolean, positionLeft: number, positionTop: number, elWidth: number, elHeight: number): Hit | null;
    isValidSegDownEl(el: HTMLElement): boolean;
    isValidDateDownEl(el: HTMLElement): boolean;
}

declare abstract class Interaction {
    component: DateComponent<any>;
    isHitComboAllowed: ((hit0: Hit, hit1: Hit) => boolean) | null;
    constructor(settings: InteractionSettings);
    destroy(): void;
}
type InteractionClass = {
    new (settings: InteractionSettings): Interaction;
};
interface InteractionSettingsInput {
    el: HTMLElement;
    useEventCenter?: boolean;
    isHitComboAllowed?: (hit0: Hit, hit1: Hit) => boolean;
    disableHits?: boolean;
}
interface InteractionSettings {
    component: DateComponent<any>;
    el: HTMLElement;
    useEventCenter: boolean;
    isHitComboAllowed: ((hit0: Hit, hit1: Hit) => boolean) | null;
}

interface ViewContext extends CalendarContext {
    options: ViewOptionsRefined;
    dateProfileGenerator: DateProfileGenerator;
    viewSpec: ViewSpec;
    viewApi: ViewImpl;
    baseId: string;
    registerInteractiveComponent: (component: DateComponent<any>, settingsInput: InteractionSettingsInput) => void;
    unregisterInteractiveComponent: (component: DateComponent<any>) => void;
}

declare abstract class ElementDragging {
    emitter: Emitter<any>;
    constructor(el: HTMLElement, selector?: string);
    destroy(): void;
    abstract cancel(): void;
    setMirrorIsVisible(bool: boolean): void;
    setMirrorNeedsRevert(bool: boolean): void;
    setAutoScrollEnabled(bool: boolean): void;
}
type ElementDraggingClass = {
    new (el: HTMLElement, selector?: string): ElementDragging;
};

interface CalendarInnerProps extends CalendarData {
    forPrint: boolean;
    baseId: string;
}
interface CalendarContentProps extends CalendarData {
    toolbarProps: CalendarToolbarProps;
    forPrint: boolean;
}
declare class CalendarInner extends PureComponent<CalendarInnerProps> {
    private buildViewContext;
    private buildViewPropTransformers;
    private interactionsStore;
    private calendarInteractions;
    private get viewTitleId();
    render(): react_jsx_runtime.JSX.Element;
    private renderView;
    private buildAppendContent;
    componentDidMount(): void;
    componentDidUpdate(prevProps: Readonly<CalendarData>): void;
    componentWillUnmount(): void;
    private registerInteractiveComponent;
    private unregisterInteractiveComponent;
}

interface ScrollerInterface {
    x: number;
    y: number;
    scrollTo(options: {
        x?: number;
        y?: number;
    }): void;
    addScrollStartListener(handler: () => void): void;
    removeScrollStartListener(handler: () => void): void;
    addScrollEndListener(handler: (isDevice: boolean) => void): void;
    removeScrollEndListener(handler: (isDevice: boolean) => void): void;
}

interface ScrollerSyncerClass {
    new (horizontal?: boolean): ScrollerSyncerInterface;
}
interface ScrollerSyncerInterface extends ScrollerInterface {
    handleChildren(scrollers: ScrollerInterface[]): void;
    destroy(): void;
    addScrollStartListener(handler: (isDevice: boolean) => void): void;
    removeScrollStartListener(handler: (isDevice: boolean) => void): void;
    addScrollListener(handler: (isDevice: boolean, scroll: number) => void): void;
    removeScrollListener(handler: (isDevice: boolean, scroll: number) => void): void;
}

type CssDimValue = string | number;
declare function getIsHeightAuto(options: {
    height?: CssDimValue;
    contentHeight?: CssDimValue;
}): boolean;
declare function getTableHeaderSticky(options: {
    height?: CssDimValue;
    contentHeight?: CssDimValue;
    tableHeaderSticky?: boolean | 'auto';
}): boolean;
declare function getFooterScrollbarSticky(options: {
    height?: CssDimValue;
    contentHeight?: CssDimValue;
    footerScrollbarSticky?: boolean | 'auto';
}): boolean;

type ContentContainerProps<RenderProps> = ElAttrsProps & ContentGeneratorProps<RenderProps> & {
    tag?: string;
    classNameGenerator?: ClassNameGenerator<RenderProps> | undefined;
    didMount?: ((renderProps: RenderProps & {
        el: HTMLElement;
    }) => void) | undefined;
    willUnmount?: ((renderProps: RenderProps & {
        el: HTMLElement;
    }) => void) | undefined;
    children?: InnerContainerFunc<RenderProps>;
};
declare class ContentContainer<RenderProps> extends Component<ContentContainerProps<RenderProps>> {
    static contextType: react.Context<number>;
    didMountMisfire?: boolean;
    context: number;
    el: HTMLElement;
    InnerContent: (props: ElProps) => react.CElement<ContentInjectorProps<unknown>, ContentInjector<unknown>>;
    render(): ReactNode;
    handleEl: (el: HTMLElement | null) => void;
    componentDidMount(): void;
    componentWillUnmount(): void;
}
type InnerContainerComponent = FC<ElProps>;
type InnerContainerFunc<RenderProps> = (InnerContainer: InnerContainerComponent, renderProps: RenderProps, attrs: ElAttrs) => ReactNode;
declare function generateClassName<RenderProps>(classNameGenerator: ClassNameGenerator<RenderProps> | undefined, renderProps: RenderProps): string;

interface NowIndicatorHeaderContainerProps extends Partial<ElProps> {
    date: DateMarker;
    children?: InnerContainerFunc<NowIndicatorHeaderInfo>;
}
interface NowIndicatorHeaderInfo {
    date: Date;
    view: ViewApi;
}
declare const NowIndicatorHeaderContainer: (props: NowIndicatorHeaderContainerProps) => react_jsx_runtime.JSX.Element;

interface NowIndicatorLineContainerProps extends Partial<ElProps> {
    date: DateMarker;
    children?: InnerContainerFunc<NowIndicatorLineInfo>;
}
interface NowIndicatorLineInfo {
    date: Date;
    view: ViewApi;
}
declare const NowIndicatorLineContainer: (props: NowIndicatorLineContainerProps) => react_jsx_runtime.JSX.Element;

interface MoreLinkContainerProps extends Partial<ElAttrsProps> {
    dateProfile: DateProfile;
    todayRange: DateRange;
    allDayDate: DateMarker | null;
    segs: EventRangeProps[];
    hiddenSegs: EventRangeProps[];
    dateSpanProps?: Dictionary;
    renderProps?: Dictionary;
    alignElRef?: RefObject<HTMLElement>;
    alignParentTop?: string;
    forceTimed?: boolean;
    popoverContent: () => ReactNode;
    isNarrow: boolean;
    isMicro: boolean;
    display: 'row' | 'column';
}
interface MoreLinkInfo$1 {
    num: number;
    numericText: string;
    longText: string;
    text: string;
    isNarrow: boolean;
    view: ViewApi;
}
interface MoreLinkContainerState {
    isPopoverOpen: boolean;
}
declare class MoreLinkContainer extends BaseComponent<MoreLinkContainerProps, MoreLinkContainerState> {
    private linkEl;
    state: {
        isPopoverOpen: boolean;
    };
    render(): react_jsx_runtime.JSX.Element;
    handleLinkEl: (linkEl: HTMLElement | null) => void;
    handleClick: (ev: MouseEvent) => void;
    handlePopoverClose: () => void;
}

interface CalendarDisplayInfo {
    borderlessX: boolean;
    borderlessTop: boolean;
    borderlessBottom: boolean;
}
interface CalendarMediaRootProps {
    emitter: Emitter<Required<CalendarListeners>>;
    children?: (forPrint: boolean) => ReactElement;
}
interface CalendarMediaRootState {
    forPrint: boolean;
}
declare class CalendarMediaRoot extends Component<CalendarMediaRootProps, CalendarMediaRootState> {
    state: CalendarMediaRootState;
    render(): ReactElement<unknown, string | react.JSXElementConstructor<any>>;
    componentDidMount(): void;
    componentWillUnmount(): void;
    private handleBeforePrint;
    private handleAfterPrint;
}
declare function computeRootClassName(options: CalendarOptions, forPrint: boolean): string;

declare class Store<Value> {
    private handlers;
    private currentValue;
    set(value: Value): void;
    subscribe(handler: (value: Value) => void): void;
}

type CustomRenderingHandler<RenderProps> = (customRender: CustomRendering<RenderProps>) => void;
interface CustomRendering<RenderProps> {
    id: string;
    isActive: boolean;
    containerEl: HTMLElement;
    generatorMeta: any;
    renderProps: RenderProps;
}
declare class CustomRenderingStore<RenderProps> extends Store<Map<string, CustomRendering<RenderProps>>> {
    private map;
    handle(customRendering: CustomRendering<RenderProps>): void;
}

interface SlotLaneInfo extends DateMeta {
    time?: Duration;
    isMajor: boolean;
    isMinor: boolean;
    view: ViewApi;
}
interface SlotHeaderInfo extends SlotLaneInfo {
    level: number;
    isTime: boolean;
    text: string;
    isNarrow: boolean;
    hasNavLink: boolean;
    isFirst: boolean;
}
interface AllDayHeaderInfo {
    text: string;
    view: ViewApi;
    isNarrow: boolean;
}
interface DayHeaderInfo extends DateMeta {
    date: Date;
    isNarrow: boolean;
    isMajor: boolean;
    inPopover: boolean;
    hasNavLink: boolean;
    level: number;
    text: string;
    textParts: DateTimeFormatPartWithWeek$1[];
    weekdayText: string;
    dayNumberText: string;
    view: ViewApi;
    [otherProp: string]: any;
}
interface DayHeaderDividerInfo {
    isSticky: boolean;
    multiMonthColumns: number;
    options: {
        allDaySlot: boolean;
    };
}
interface DayCellInfo extends DateMeta {
    date: DateMarker;
    isMajor: boolean;
    isNarrow: boolean;
    inPopover: boolean;
    hasNavLink: boolean;
    view: ViewApi;
    text: string;
    textParts: DateTimeFormatPartWithWeek$1[];
    weekdayText: string;
    dayNumberText: string;
    monthText: string;
    options: {
        businessHours: boolean;
    };
    [extraProp: string]: any;
}

type EventSourceFuncInfo = {
    start: Date;
    end: Date;
    startStr: string;
    endStr: string;
    timeZone: string;
};
type EventSourceFunc = ((info: EventSourceFuncInfo, successCallback: (eventInputs: EventInput[]) => void, failureCallback: (error: Error) => void) => void) | ((info: EventSourceFuncInfo) => Promise<EventInput[]>);

declare const JSON_FEED_EVENT_SOURCE_REFINERS: {
    method: StringConstructor;
    extraParams: Identity<Dictionary | (() => Dictionary)>;
    startParam: StringConstructor;
    endParam: StringConstructor;
    timeZoneParam: StringConstructor;
};

declare const EVENT_SOURCE_REFINERS: {
    id: StringConstructor;
    defaultAllDay: BooleanConstructor;
    url: StringConstructor;
    format: StringConstructor;
    events: Identity<EventInput[] | EventSourceFunc>;
    eventDataTransform: Identity<EventInputTransformer>;
    success: Identity<EventSourceSuccessResponseHandler>;
    failure: Identity<EventSourceErrorResponseHandler>;
};
type BuiltInEventSourceRefiners = typeof EVENT_SOURCE_REFINERS & typeof JSON_FEED_EVENT_SOURCE_REFINERS;
declare module '@fullcalendar/core/protected-api' {
    interface EventSourceOptions extends RawOptionsFromRefiners<BuiltInEventSourceRefiners> {
    }
    interface EventSourceOptionsRefined extends RefinedOptionsFromRefiners<BuiltInEventSourceRefiners> {
    }
}
type EventSourceInputObject = EventUiInput & EventSourceOptions;
type EventSourceInput = EventSourceInputObject | // object in extended form
EventInput[] | EventSourceFunc | // just a function
string;
type EventSourceRefined = EventUiRefined & EventSourceOptionsRefined;

type DateTimeFormatPartWithWeek = Omit<Intl.DateTimeFormatPart, 'type'> & {
    type: Intl.DateTimeFormatPart['type'] | 'week';
};
interface WeekNumberHeaderInfo {
    num?: number;
    date?: Date;
    text: string;
    textParts: DateTimeFormatPartWithWeek[];
    isNarrow: boolean;
    hasNavLink: boolean;
    options: {
        dayMinWidth: number | undefined;
    };
}
interface InlineWeekNumberInfo {
    num: number;
    date: Date;
    text: string;
    textParts: DateTimeFormatPartWithWeek[];
    isNarrow: boolean;
    hasNavLink: boolean;
}

interface EventSegment {
    event: EventApi;
    start: Date;
    end: Date;
    isStart: boolean;
    isEnd: boolean;
}
type MoreLinkAction = MoreLinkSimpleAction | MoreLinkHandler;
type MoreLinkSimpleAction = 'popover' | 'week' | 'day' | 'timeGridWeek' | 'timeGridDay' | string;
interface MoreLinkInfo {
    date: Date;
    allDay: boolean;
    allSegs: EventSegment[];
    hiddenSegs: EventSegment[];
    jsEvent: UIEvent;
    view: ViewApi;
}
type MoreLinkHandler = (info: MoreLinkInfo) => MoreLinkSimpleAction | void;

interface DayLaneInfo extends DateMeta {
    date: DateMarker;
    isNarrow: boolean;
    isStack: boolean;
    isMajor: boolean;
    view: ViewApi;
    [extraProp: string]: any;
}

type TableDisplayInfo = {
    borderlessX: boolean;
    borderlessTop: boolean;
    borderlessBottom: boolean;
    multiMonthColumns: number;
};
type TableHeaderInfo = TableDisplayInfo & {
    isSticky: boolean;
};
type TableBodyInfo = TableDisplayInfo;

interface EventClickInfo {
    el: HTMLElement;
    event: EventImpl;
    jsEvent: MouseEvent;
    view: ViewApi;
}

interface EventHoveringInfo {
    el: HTMLElement;
    event: EventImpl;
    jsEvent: MouseEvent;
    view: ViewApi;
}

interface DateSelectionApi extends DateSpanApi {
    jsEvent: UIEvent;
    view: ViewApi;
}
type DatePointTransform = (dateSpan: DateSpan, context: CalendarContext) => any;
type DateSpanTransform = (dateSpan: DateSpan, context: CalendarContext) => any;
type CalendarInteraction = {
    destroy: () => void;
};
type CalendarInteractionClass = {
    new (context: CalendarContext): CalendarInteraction;
};
type OptionChangeHandler = (propValue: any, context: CalendarContext) => void;
type OptionChangeHandlerMap = {
    [propName: string]: OptionChangeHandler;
};
interface DateSelectInfo extends DateSpanApi {
    jsEvent: MouseEvent | null;
    view: ViewApi;
}
interface DateUnselectInfo {
    jsEvent: MouseEvent;
    view: ViewApi;
}

type DatesSetInfo = RangeApiWithTimeZone & {
    view: ViewApi;
};

interface EventAddInfo {
    event: EventImpl;
    relatedEvents: EventImpl[];
    revert: () => void;
}
interface EventChangeInfo {
    oldEvent: EventImpl;
    event: EventImpl;
    relatedEvents: EventImpl[];
    revert: () => void;
}
interface EventDropInfo extends EventChangeInfo {
    el: HTMLElement;
    delta: Duration;
    jsEvent: MouseEvent;
    view: ViewApi;
}
interface EventRemoveInfo {
    event: EventImpl;
    relatedEvents: EventImpl[];
    revert: () => void;
}

interface ButtonState {
    text: string;
    hint: string;
}
interface NavButtonState extends ButtonState {
    isDisabled: boolean;
}
interface ButtonStateMap {
    today: NavButtonState;
    prev: NavButtonState;
    next: NavButtonState;
    prevYear: NavButtonState;
    nextYear: NavButtonState;
    [availableView: string]: ButtonState;
}

interface NoEventsInfo {
    text: string;
    view: ViewApi;
}

interface ListDayInfo extends DateMeta {
    isFirst: boolean;
    isLast: boolean;
    view: ViewApi;
}
interface ListDayHeaderInfo extends DateMeta {
    view: ViewApi;
}
interface ListDayEventsInfo extends DateMeta {
    view: ViewApi;
}
interface ListDayHeaderInnerInfo extends DateMeta {
    text: string;
    textParts: DateTimeFormatPartWithWeek$1[];
    weekdayText: string;
    dayNumberText: string;
    hasNavLink: boolean;
    level: number;
    view: ViewApi;
}

interface SingleMonthInfo {
    multiMonthColumns: number;
    isFirst: boolean;
    isLast: boolean;
}
type SingleMonthHeaderInfo = {
    isSticky: boolean;
    isNarrow: boolean;
    hasNavLink: boolean;
    multiMonthColumns: number;
};

type EventDragStopInfo = EventDragInfo;
type EventDragStartInfo = EventDragInfo;
interface EventDragInfo {
    el: HTMLElement;
    event: EventApi;
    jsEvent: MouseEvent;
    view: ViewApi;
}

type EventResizeStartInfo = EventResizeStartStopData;
type EventResizeStopInfo = EventResizeStartStopData;
interface EventResizeStartStopData {
    el: HTMLElement;
    event: EventApi;
    jsEvent: MouseEvent;
    view: ViewApi;
}
interface EventResizeDoneInfo extends EventChangeInfo {
    el: HTMLElement;
    startDelta: Duration;
    endDelta: Duration;
    jsEvent: MouseEvent;
    view: ViewApi;
}

interface DateClickInfo extends DatePointApi {
    dayEl: HTMLElement;
    jsEvent: MouseEvent;
    view: ViewApi;
}

interface DropInfo extends DatePointApi {
    draggedEl: HTMLElement;
    jsEvent: MouseEvent;
    view: ViewApi;
}
type EventReceiveInfo = EventReceiveLeaveData;
type EventLeaveInfo = EventReceiveLeaveData;
interface EventReceiveLeaveData {
    draggedEl: HTMLElement;
    event: EventApi;
    relatedEvents: EventApi[];
    revert: () => void;
    view: ViewApi;
}

interface EventApi {
    source: EventSourceApi | null;
    start: Date | null;
    end: Date | null;
    startStr: string;
    endStr: string;
    id: string;
    groupId: string;
    allDay: boolean;
    title: string;
    url: string;
    display: string;
    startEditable: boolean;
    durationEditable: boolean;
    constraint: any;
    overlap: boolean;
    allow: any;
    color: string;
    contrastColor: string;
    className: string;
    extendedProps: Dictionary;
    setProp(name: string, val: any): void;
    setExtendedProp(name: string, val: any): void;
    setStart(startInput: DateInput, options?: {
        granularity?: string;
        maintainDuration?: boolean;
    }): void;
    setEnd(endInput: DateInput | null, options?: {
        granularity?: string;
    }): void;
    setDates(startInput: DateInput, endInput: DateInput | null, options?: {
        allDay?: boolean;
        granularity?: string;
    }): void;
    moveStart(deltaInput: DurationInput): void;
    moveEnd(deltaInput: DurationInput): void;
    moveDates(deltaInput: DurationInput): void;
    setAllDay(allDay: boolean, options?: {
        maintainDuration?: boolean;
    }): void;
    formatRange(formatInput: FormatterInput): any;
    remove(): void;
    toPlainObject(settings?: {
        collapseExtendedProps?: boolean;
    }): Dictionary;
    toJSON(): Dictionary;
}

interface CalendarApi {
    view: ViewApi;
    setOption<OptionName extends keyof CalendarOptions>(name: OptionName, val: CalendarOptions[OptionName]): void;
    getOption<OptionName extends keyof CalendarOptions>(name: OptionName): CalendarOptions[OptionName];
    getAvailableLocaleCodes(): string[];
    on<ListenerName extends keyof CalendarListeners>(handlerName: ListenerName, handler: Required<CalendarListeners>[ListenerName]): void;
    off<ListenerName extends keyof CalendarListeners>(handlerName: ListenerName, handler: Required<CalendarListeners>[ListenerName]): void;
    trigger<ListenerName extends keyof CalendarListeners>(handlerName: ListenerName, ...args: Parameters<Required<CalendarListeners>[ListenerName]>): void;
    changeView(viewType: string, dateOrRange?: DateRangeInput | DateInput): void;
    zoomTo(dateMarker: Date, viewType?: string): void;
    prev(): void;
    next(): void;
    prevYear(): void;
    nextYear(): void;
    today(): void;
    gotoDate(zonedDateInput: DateInput): void;
    incrementDate(deltaInput: DurationInput): void;
    getDate(): Date;
    formatDate(d: DateInput, formatter: FormatterInput): string;
    formatRange(d0: DateInput, d1: DateInput, settings: any): string;
    formatIso(d: DateInput, omitTime?: boolean): string;
    select(dateOrObj: DateInput | any, endDate?: DateInput): void;
    unselect(): void;
    addEvent(eventInput: EventInput, sourceInput?: EventSourceApi | string | boolean): EventApi | null;
    getEventById(id: string): EventApi | null;
    getEvents(): EventApi[];
    removeAllEvents(): void;
    getEventSources(): EventSourceApi[];
    getEventSourceById(id: string): EventSourceApi | null;
    addEventSource(sourceInput: EventSourceInput): EventSourceApi;
    removeAllEventSources(): void;
    refetchEvents(): void;
    scrollToTime(timeInput: DurationInput): void;
}

declare class CalendarController {
    private handleDateChange?;
    private calendarApi?;
    constructor(handleDateChange?: () => void);
    today(): void;
    prev(): void;
    next(): void;
    prevYear(): void;
    nextYear(): void;
    gotoDate(zonedDateInput: DateInput): void;
    incrementDate(duration: DurationInput): void;
    changeView(viewType: string): void;
    get view(): ViewApi | undefined;
    getDate(): Date | undefined;
    getButtonState(): ButtonStateMap;
    _setApi(calendarApi: CalendarApi | undefined): void;
}

declare class EventSourceImpl implements EventSourceApi {
    private context;
    internalEventSource: EventSource<any>;
    constructor(context: CalendarContext, internalEventSource: EventSource<any>);
    remove(): void;
    refetch(): void;
    get id(): string;
    get url(): string;
    get format(): string;
}

declare class EventImpl implements EventApi {
    _context: CalendarContext;
    _def: EventDef;
    _instance: EventInstance | null;
    constructor(context: CalendarContext, def: EventDef, instance?: EventInstance);
    setProp(name: string, val: any): void;
    setExtendedProp(name: string, val: any): void;
    setStart(startInput: DateInput, options?: {
        granularity?: string;
        maintainDuration?: boolean;
    }): void;
    setEnd(endInput: DateInput | null, options?: {
        granularity?: string;
    }): void;
    setDates(startInput: DateInput, endInput: DateInput | null, options?: {
        allDay?: boolean;
        granularity?: string;
    }): void;
    moveStart(deltaInput: DurationInput): void;
    moveEnd(deltaInput: DurationInput): void;
    moveDates(deltaInput: DurationInput): void;
    setAllDay(allDay: boolean, options?: {
        maintainDuration?: boolean;
    }): void;
    formatRange(formatInput: FormatterInput): string;
    mutate(mutation: EventMutation): void;
    remove(): void;
    get source(): EventSourceImpl | null;
    get start(): Date | null;
    get end(): Date | null;
    get startStr(): string;
    get endStr(): string;
    get id(): string;
    get groupId(): string;
    get allDay(): boolean;
    get title(): string;
    get url(): string;
    get display(): string;
    get startEditable(): boolean;
    get durationEditable(): boolean;
    get constraint(): string | EventStore;
    get overlap(): boolean;
    get allow(): AllowFunc;
    get color(): string;
    get contrastColor(): string;
    get className(): string;
    get extendedProps(): Dictionary;
    toPlainObject(settings?: {
        collapseExtendedProps?: boolean;
    }): Dictionary;
    toJSON(): Dictionary;
}

interface EventRenderRange extends EventTuple {
    ui: EventUi;
    range: EventInstanceRange;
    isStart: boolean;
    isEnd: boolean;
}
interface EventRangeProps {
    eventRange: EventRenderRange;
}
declare function sortEventSegs<S extends EventRangeProps>(segs: S[], eventOrderSpecs: OrderSpec<EventImpl>[]): S[];
interface MinimalEventProps {
    eventRange: EventRenderRange;
    slicedStart?: DateMarker;
    slicedEnd?: DateMarker;
    isStart: boolean;
    isEnd: boolean;
    isFirst?: boolean;
    isLast?: boolean;
    isDragging: boolean;
    isResizing: boolean;
    isMirror: boolean;
    isSelected: boolean;
    isPast: boolean;
    isFuture: boolean;
    isToday: boolean;
    renderProps?: Dictionary;
}
interface EventTextInfo {
    event: EventApi;
    timeText: string;
    isNarrow: boolean;
    isShort: boolean;
}
interface EventDisplayInfo extends EventTextInfo {
    event: EventImpl;
    color: string;
    contrastColor: string;
    isDraggable: boolean;
    isStartResizable: boolean;
    isEndResizable: boolean;
    isMirror: boolean;
    isStart: boolean;
    isEnd: boolean;
    isFirst: boolean;
    isLast: boolean;
    isPast: boolean;
    isFuture: boolean;
    isToday: boolean;
    isSelected: boolean;
    isDragging: boolean;
    isResizing: boolean;
    isInteractive: boolean;
    view: ViewApi;
    level: number;
    timeClass: string;
    titleClass: string;
    options: {
        eventOverlap: boolean;
    };
}
declare function getEventRangeMeta(eventRange: EventRenderRange, todayRange: DateRange, nowDate?: DateMarker, nowMs?: number): {
    isPast: boolean;
    isFuture: boolean;
    isToday: boolean;
};
declare function buildEventRangeKey(eventRange: EventRenderRange): string;

interface OpenDateSpanInput {
    start?: DateInput;
    end?: DateInput;
    allDay?: boolean;
    [otherProp: string]: any;
}
interface DateSpanInput extends OpenDateSpanInput {
    start: DateInput;
    end: DateInput;
}
interface OpenDateSpan {
    range: OpenDateRange;
    allDay: boolean;
    instantStartMs?: number;
    instantEndMs?: number;
    [otherProp: string]: any;
}
interface DateSpan extends OpenDateSpan {
    range: DateRange;
}
interface RangeApi {
    start: Date;
    end: Date;
    startStr: string;
    endStr: string;
}
interface DateSpanApi extends RangeApi {
    allDay: boolean;
}
interface RangeApiWithTimeZone extends RangeApi {
    timeZone: string;
}
interface DatePointApi {
    date: Date;
    dateStr: string;
    allDay: boolean;
}
declare function getDateSpanInstantStartMs(dateSpan: DateSpan, dateEnv: DateEnv): number;
declare function getDateSpanInstantEndMs(dateSpan: DateSpan, dateEnv: DateEnv): number;

type ConstraintInput = 'businessHours' | string | EventInput | EventInput[];
type Constraint = 'businessHours' | string | EventStore | false;
type OverlapFunc = ((stillEvent: EventImpl, movingEvent: EventImpl | null) => boolean);
type AllowFunc = (span: DateSpanApi, movingEvent: EventImpl | null) => boolean;
type isPropsValidTester = (props: SplittableProps, context: CalendarContext) => boolean;

declare const EVENT_UI_REFINERS: {
    display: StringConstructor;
    editable: BooleanConstructor;
    startEditable: BooleanConstructor;
    durationEditable: BooleanConstructor;
    constraint: Identity<any>;
    overlap: Identity<boolean>;
    allow: Identity<AllowFunc>;
    class: typeof refineClassName;
    className: typeof refineClassName;
    color: StringConstructor;
    contrastColor: StringConstructor;
};
type BuiltInEventUiRefiners = typeof EVENT_UI_REFINERS;
interface EventUiRefiners extends BuiltInEventUiRefiners {
}
type EventUiInput = RawOptionsFromRefiners<Required<EventUiRefiners>>;
type EventUiRefined = RefinedOptionsFromRefiners<Required<EventUiRefiners>>;
interface EventUi {
    display: string | null;
    startEditable: boolean | null;
    durationEditable: boolean | null;
    constraints: Constraint[];
    overlap: boolean | null;
    allows: AllowFunc[];
    color: string;
    contrastColor: string;
    className: string;
}
type EventUiHash = {
    [defId: string]: EventUi;
};
declare function createEventUi(refined: EventUiRefined, context: CalendarContext): EventUi;
declare function combineEventUis(uis: EventUi[]): EventUi;

interface EventDef {
    defId: string;
    sourceId: string;
    publicId: string;
    groupId: string;
    allDay: boolean;
    hasEnd: boolean;
    recurringDef: {
        typeId: number;
        typeData: any;
        duration: Duration | null;
    } | null;
    title: string;
    url: string;
    ui: EventUi;
    interactive?: boolean;
    extendedProps: Dictionary;
}
type EventDefHash = {
    [defId: string]: EventDef;
};

interface EventStore {
    defs: EventDefHash;
    instances: EventInstanceHash;
}
declare function mergeEventStores(store0: EventStore, store1: EventStore): EventStore;

interface EventMutation {
    datesDelta?: Duration;
    startDelta?: Duration;
    endDelta?: Duration;
    instantDatesDeltaMs?: number;
    instantStartDeltaMs?: number;
    instantEndDeltaMs?: number;
    standardProps?: any;
    extendedProps?: any;
}
type eventDefMutationApplier = (eventDef: EventDef, mutation: EventMutation, context: CalendarContext) => void;

type eventDragMutationMassager = (mutation: EventMutation, hit0: Hit, hit1: Hit) => void;
type EventDropTransformers = (mutation: EventMutation, context: CalendarContext) => Dictionary;
type eventIsDraggableTransformer = (val: boolean, eventDef: EventDef, eventUi: EventUi, context: CalendarContext) => boolean;

type dateSelectionJoinTransformer = (hit0: Hit, hit1: Hit) => any;

declare const DRAG_META_REFINERS: {
    startTime: typeof createDuration;
    duration: typeof createDuration;
    create: BooleanConstructor;
    sourceId: StringConstructor;
};
type DragMetaInput = RawOptionsFromRefiners<typeof DRAG_META_REFINERS> & {
    [otherProp: string]: any;
};
interface DragMeta {
    startTime: Duration | null;
    duration: Duration | null;
    create: boolean;
    sourceId: string;
    leftoverProps: Dictionary;
}

type ExternalDefTransform = (dateSpan: DateSpan, dragMeta: DragMeta) => any;

interface EventSourceDef<Meta> {
    ignoreRange?: boolean;
    parseMeta: (refined: EventSourceRefined) => Meta | null;
    fetch: EventSourceFetcher<Meta>;
}

interface ParsedRecurring<RecurringData> {
    typeData: RecurringData;
    allDayGuess: boolean | null;
    duration: Duration | null;
}
interface RecurringType<RecurringData> {
    parse: (refined: EventRefined, dateEnv: DateEnv) => ParsedRecurring<RecurringData> | null;
    expand: (typeData: any, framingRange: DateRange, dateEnv: DateEnv) => DateMarker[];
}

interface PluginInput {
    name: string;
    premiumReleaseDate?: string;
    deps?: PluginInput[];
    reducers?: ReducerFunc[];
    isLoadingFuncs?: ((state: Dictionary) => boolean)[];
    contextInit?: (context: CalendarContext) => void;
    eventRefiners?: GenericRefiners;
    eventDefMemberAdders?: EventDefMemberAdder[];
    eventSourceRefiners?: GenericRefiners;
    isDraggableTransformers?: eventIsDraggableTransformer[];
    eventDragMutationMassagers?: eventDragMutationMassager[];
    eventDefMutationAppliers?: eventDefMutationApplier[];
    dateSelectionTransformers?: dateSelectionJoinTransformer[];
    datePointTransforms?: DatePointTransform[];
    dateSpanTransforms?: DateSpanTransform[];
    views?: ViewConfigInputHash;
    viewPropsTransformers?: ViewPropsTransformerClass[];
    isPropsValid?: isPropsValidTester;
    externalDefTransforms?: ExternalDefTransform[];
    viewContainerAppends?: ViewContainerAppend[];
    eventDropTransformers?: EventDropTransformers[];
    componentInteractions?: InteractionClass[];
    calendarInteractions?: CalendarInteractionClass[];
    eventSourceDefs?: EventSourceDef<any>[];
    cmdFormatter?: CmdDateFormatterFunc;
    recurringTypes?: RecurringType<any>[];
    initialView?: string;
    elementDraggingImpl?: ElementDraggingClass;
    optionChangeHandlers?: OptionChangeHandlerMap;
    scrollerSyncerClass?: ScrollerSyncerClass;
    listenerRefiners?: GenericListenerRefiners;
    optionRefiners?: GenericRefiners;
    optionDefaults?: CalendarOptions;
    propSetHandlers?: {
        [propName: string]: (val: any, context: CalendarData) => void;
    };
}
interface PluginHooks {
    premiumReleaseDate: Date | undefined;
    reducers: ReducerFunc[];
    isLoadingFuncs: ((state: Dictionary) => boolean)[];
    contextInit: ((context: CalendarContext) => void)[];
    eventRefiners: GenericRefiners;
    eventDefMemberAdders: EventDefMemberAdder[];
    eventSourceRefiners: GenericRefiners;
    isDraggableTransformers: eventIsDraggableTransformer[];
    eventDragMutationMassagers: eventDragMutationMassager[];
    eventDefMutationAppliers: eventDefMutationApplier[];
    dateSelectionTransformers: dateSelectionJoinTransformer[];
    datePointTransforms: DatePointTransform[];
    dateSpanTransforms: DateSpanTransform[];
    views: ViewConfigInputHash;
    viewPropsTransformers: ViewPropsTransformerClass[];
    isPropsValid: isPropsValidTester | null;
    externalDefTransforms: ExternalDefTransform[];
    viewContainerAppends: ViewContainerAppend[];
    eventDropTransformers: EventDropTransformers[];
    componentInteractions: InteractionClass[];
    calendarInteractions: CalendarInteractionClass[];
    eventSourceDefs: EventSourceDef<any>[];
    cmdFormatter?: CmdDateFormatterFunc;
    recurringTypes: RecurringType<any>[];
    initialView: string;
    elementDraggingImpl?: ElementDraggingClass;
    optionChangeHandlers: OptionChangeHandlerMap;
    scrollerSyncerClass: ScrollerSyncerClass | null;
    listenerRefiners: GenericListenerRefiners;
    optionRefiners: GenericRefiners;
    optionDefaults: CalendarOptions[];
    propSetHandlers: {
        [propName: string]: (val: any, context: CalendarData) => void;
    };
}
type ViewPropsTransformerClass = new () => ViewPropsTransformer;
interface ViewPropsTransformer {
    transform(viewProps: ViewProps, calendarProps: CalendarContentProps): any;
}
type ViewContainerAppend = (context: CalendarContext) => ReactNode;

interface CalendarContext {
    nowManager: CalendarNowManager;
    dateEnv: DateEnv;
    options: BaseOptionsRefined;
    pluginHooks: PluginHooks;
    emitter: Emitter<Required<CalendarListeners>>;
    dispatch(action: Action): void;
    getCurrentData(): CalendarData;
    calendarApi: CalendarApiImpl;
}

declare const EVENT_REFINERS: {
    extendedProps: Identity<Dictionary>;
    start: Identity<DateInput>;
    end: Identity<DateInput>;
    date: Identity<DateInput>;
    allDay: BooleanConstructor;
    id: StringConstructor;
    groupId: StringConstructor;
    title: StringConstructor;
    url: StringConstructor;
    interactive: BooleanConstructor;
};
type BuiltInEventRefiners = typeof EVENT_REFINERS;
declare module '@fullcalendar/core/protected-api' {
    interface EventRefiners extends BuiltInEventRefiners {
    }
}
type EventInput = EventUiInput & RawOptionsFromRefiners<Required<EventRefiners>> & // Required hack
{
    [extendedProp: string]: any;
};
type EventRefined = EventUiRefined & RefinedOptionsFromRefiners<Required<EventRefiners>>;
interface EventTuple {
    def: EventDef;
    instance: EventInstance | null;
}
type EventInputTransformer = (input: EventInput) => EventInput;
type EventDefMemberAdder = (refined: EventRefined) => Partial<EventDef>;

type Action = {
    type: 'IDLE';
} | // hack
{
    type: 'UPDATE_NOW';
} | {
    type: 'SET_OPTION';
    optionName: string;
    rawOptionValue: any;
} | // TODO: how to link this to CalendarOptions?
{
    type: 'RESET_OPTIONS';
} | {
    type: 'PREV';
} | {
    type: 'NEXT';
} | {
    type: 'CHANGE_DATE';
    dateMarker: DateMarker;
} | {
    type: 'CHANGE_VIEW_TYPE';
    viewType: string;
    dateMarker?: DateMarker;
} | {
    type: 'SELECT_DATES';
    selection: DateSpan;
} | {
    type: 'UNSELECT_DATES';
} | {
    type: 'SELECT_EVENT';
    eventInstanceId: string;
} | {
    type: 'UNSELECT_EVENT';
} | {
    type: 'SET_EVENT_DRAG';
    state: EventInteractionState;
} | {
    type: 'UNSET_EVENT_DRAG';
} | {
    type: 'SET_EVENT_RESIZE';
    state: EventInteractionState;
} | {
    type: 'UNSET_EVENT_RESIZE';
} | {
    type: 'ADD_EVENT_SOURCES';
    sources: EventSource<any>[];
} | {
    type: 'REMOVE_EVENT_SOURCE';
    sourceId: string;
} | {
    type: 'REMOVE_ALL_EVENT_SOURCES';
} | {
    type: 'FETCH_EVENT_SOURCES';
    sourceIds?: string[];
    isRefetch?: boolean;
} | // if no sourceIds, fetch all
{
    type: 'RECEIVE_EVENTS';
    sourceId: string;
    fetchId: string;
    fetchRange: DateRange | null;
    rawEvents: EventInput[];
} | {
    type: 'RECEIVE_EVENT_ERROR';
    sourceId: string;
    fetchId: string;
    fetchRange: DateRange | null;
    error: Error;
} | // need all these?
{
    type: 'ADD_EVENTS';
    eventStore: EventStore;
} | {
    type: 'RESET_EVENTS';
    eventStore: EventStore;
} | {
    type: 'RESET_RAW_EVENTS';
    rawEvents: EventInput[];
    sourceId: string;
} | {
    type: 'MERGE_EVENTS';
    eventStore: EventStore;
} | {
    type: 'REMOVE_EVENTS';
    eventStore: EventStore;
} | {
    type: 'REMOVE_ALL_EVENTS';
};

interface CalendarDataManagerConfig {
    calendarApi: CalendarApiImpl;
    onDataChange?: (data: CalendarData, actionsComplete: Action[]) => void;
}
type ReducerFunc = (currentState: Dictionary | undefined, action: Action | undefined, context: CalendarContext & CalendarDataManagerState) => Dictionary;
declare class CalendarDataManager {
    private computeCurrentViewData;
    private organizeRawLocales;
    private buildLocale;
    private buildPluginHooks;
    private buildDateEnv;
    private parseToolbars;
    private buildViewSpecs;
    private buildDateProfileGenerator;
    private buildViewApi;
    private buildViewUiProps;
    private buildEventUiBySource;
    private buildEventUiBases;
    private parseContextBusinessHours;
    private buildToolbarProps;
    private buildTitle;
    private nowManager;
    private nowTimer;
    private isDrainingActionQueue;
    private actionQueue;
    private optionOverrides;
    private config;
    private state;
    private data;
    emitter: Emitter<Required<CalendarListeners>>;
    currentCalendarOptionsRefiners: any;
    currentCalendarOptionsInput: CalendarOptions;
    private currentCalendarOptionsRefined;
    private currentViewOptionsInput;
    private currentViewOptionsRefined;
    private stableOptionOverrides;
    private stableDynamicOptionOverrides;
    private stableCalendarOptionsData;
    private optionsForRefining;
    private optionsForHandling;
    constructor(config: CalendarDataManagerConfig);
    destroy(): void;
    update(optionOverrides: CalendarOptions): CalendarData;
    resetOptions(optionOverrides: CalendarOptions, changedOptionNames?: string[]): void;
    getCurrentData: () => CalendarData;
    private handleNowChange;
    dispatch: (action: Action) => void;
    private drainActionQueue;
    private reduce;
    private computeOptionsData;
    private processRawCalendarOptions;
    private _computeCurrentViewData;
    private processRawViewOptions;
}

declare class CalendarApiImpl implements CalendarApi {
    currentDataManager?: CalendarDataManager;
    getCurrentData(): CalendarData;
    dispatch(action: Action): void;
    get view(): ViewImpl;
    batchRendering(callback: () => void): void;
    setOption<OptionName extends keyof CalendarOptions>(name: OptionName, val: CalendarOptions[OptionName]): void;
    getOption<OptionName extends keyof CalendarOptions>(name: OptionName): CalendarOptions[OptionName];
    getAvailableLocaleCodes(): string[];
    on<ListenerName extends keyof CalendarListeners>(handlerName: ListenerName, handler: Required<CalendarListeners>[ListenerName]): void;
    off<ListenerName extends keyof CalendarListeners>(handlerName: ListenerName, handler: Required<CalendarListeners>[ListenerName]): void;
    trigger<ListenerName extends keyof CalendarListeners>(handlerName: ListenerName, ...args: Parameters<Required<CalendarListeners>[ListenerName]>): void;
    changeView(viewType: string, dateOrRange?: DateRangeInput | DateInput): void;
    zoomTo(dateMarker: Date, viewType?: string): void;
    private getUnitViewSpec;
    prev(): void;
    next(): void;
    prevYear(): void;
    nextYear(): void;
    today(): void;
    gotoDate(zonedDateInput: DateInput): void;
    incrementDate(deltaInput: DurationInput): void;
    getDate(): Date;
    formatDate(d: DateInput, formatter: FormatterInput): string;
    formatRange(d0: DateInput, d1: DateInput, settings: any): string;
    formatIso(d: DateInput, omitTime?: boolean): string;
    select(dateOrObj: DateInput | any, endDate?: DateInput): void;
    unselect(pev?: PointerDragEvent): void;
    addEvent(eventInput: EventInput, sourceInput?: EventSourceImpl | string | boolean): EventImpl | null;
    private triggerEventAdd;
    getEventById(id: string): EventImpl | null;
    getEvents(): EventImpl[];
    removeAllEvents(): void;
    getEventSources(): EventSourceImpl[];
    getEventSourceById(id: string): EventSourceImpl | null;
    addEventSource(sourceInput: EventSourceInput): EventSourceImpl;
    removeAllEventSources(): void;
    refetchEvents(): void;
    scrollToTime(timeInput: DurationInput): void;
    getButtonState(): ButtonStateMap;
}

interface DateProfile {
    currentDate: DateMarker;
    isValid: boolean;
    validRange: OpenDateRange;
    renderRange: DateRange;
    activeRange: DateRange | null;
    currentRange: DateRange;
    currentRangeUnit: string;
    isRangeAllDay: boolean;
    dateIncrement: Duration;
    slotMinTime: Duration;
    slotMaxTime: Duration;
}
interface DateProfileGeneratorProps extends DateProfileOptions {
    dateProfileGeneratorClass: DateProfileGeneratorClass;
    duration: Duration;
    durationUnit: string;
    usesMinMaxTime: boolean;
    dateEnv: DateEnv;
    calendarApi: CalendarApiImpl;
}
interface DateProfileOptions {
    slotMinTime: Duration;
    slotMaxTime: Duration;
    showNonCurrentDates?: boolean;
    dayCount?: number;
    dateAlignment?: string;
    dateIncrement?: Duration;
    hiddenDays?: number[];
    weekends?: boolean;
    validRangeInput?: DateRangeInput | ((this: CalendarApiImpl, nowDate: Date) => DateRangeInput);
    visibleRangeInput?: DateRangeInput | ((this: CalendarApiImpl, nowDate: Date) => DateRangeInput);
    fixedWeekCount?: boolean;
}
type DateProfileGeneratorClass = {
    new (props: DateProfileGeneratorProps): DateProfileGenerator;
};
declare class DateProfileGenerator {
    protected props: DateProfileGeneratorProps;
    isHiddenDayHash: boolean[];
    constructor(props: DateProfileGeneratorProps);
    buildPrev(currentDateProfile: DateProfile, currentDate: DateMarker, nowDate: DateMarker, forceToValid?: boolean): DateProfile;
    buildNext(currentDateProfile: DateProfile, currentDate: DateMarker, nowDate: DateMarker, forceToValid?: boolean): DateProfile;
    build(currentDate: DateMarker, nowDate: DateMarker, direction?: any, forceToValid?: boolean): DateProfile;
    buildValidRange(nowDate: DateMarker): OpenDateRange;
    buildCurrentRangeInfo(date: DateMarker, direction: any): {
        duration: any;
        unit: any;
        range: any;
    };
    getFallbackDuration(): Duration;
    adjustActiveRange(range: DateRange): {
        start: Date;
        end: Date;
    };
    buildRangeFromDuration(date: DateMarker, direction: any, duration: Duration, unit: any): any;
    buildRangeFromDayCount(date: DateMarker, direction: any, dayCount: any): {
        start: Date;
        end: Date;
    };
    buildCustomVisibleRange(date: DateMarker): DateRange;
    buildRenderRange(currentRange: DateRange, currentRangeUnit: any, isRangeAllDay: any): DateRange;
    buildDateIncrement(fallback: any): Duration;
    refineRange(rangeInput: DateRangeInput | undefined): DateRange | null;
    initHiddenDays(): void;
    trimHiddenDays(range: DateRange): DateRange | null;
    isHiddenDay(day: any): boolean;
    skipHiddenDays(date: DateMarker, inc?: number, isExclusive?: boolean): Date;
}
declare function computeMajorUnit(dateProfile: DateProfile, dateEnv: DateEnv): string | undefined;
declare function isMajorUnit(dateMarker: DateMarker, majorUnit: string, dateEnv: DateEnv): boolean;

declare const BASE_OPTION_REFINERS: {
    navLinkDayClick: Identity<string | ((this: CalendarApi, date: Date, jsEvent: UIEvent) => void)>;
    navLinkWeekClick: Identity<string | ((this: CalendarApi, weekStart: Date, jsEvent: UIEvent) => void)>;
    duration: typeof createDuration;
    buttons: Identity<Partial<{
        today: ButtonInput;
        prev: ButtonInput;
        next: ButtonInput;
        prevYear: ButtonInput;
        nextYear: ButtonInput;
        year: ButtonInput;
        month: ButtonInput;
        week: ButtonInput;
        day: ButtonInput;
        [buttonName: string]: ButtonInput;
    }>>;
    toolbarElements: Identity<{
        [elementName: string]: ToolbarElementInput;
    }>;
    prevText: StringConstructor;
    nextText: StringConstructor;
    prevYearText: StringConstructor;
    nextYearText: StringConstructor;
    todayText: StringConstructor;
    yearText: StringConstructor;
    monthText: StringConstructor;
    weekTextLong: StringConstructor;
    weekTextShort: StringConstructor;
    dayText: StringConstructor;
    listText: Identity<string | false>;
    todayHint: Identity<string | ((currentUnitText: string, currentUnit: string) => string)>;
    prevHint: Identity<string | ((currentUnitText: string, currentUnit: string) => string)>;
    nextHint: Identity<string | ((currentUnitText: string, currentUnit: string) => string)>;
    buttonDisplay: Identity<ButtonDisplay>;
    buttonGroupClass: Identity<ClassNameGenerator<ButtonGroupInfo>>;
    buttonClass: Identity<ClassNameGenerator<ButtonInfo>>;
    defaultAllDayEventDuration: typeof createDuration;
    defaultTimedEventDuration: typeof createDuration;
    nextDayThreshold: typeof createDuration;
    scrollTime: typeof createDuration;
    scrollTimeReset: BooleanConstructor;
    slotMinTime: typeof createDuration;
    slotMaxTime: typeof createDuration;
    popoverFormat: typeof createFormatter;
    slotDuration: typeof createDuration;
    snapDuration: typeof createDuration;
    headerToolbar: Identity<ToolbarInput | false>;
    footerToolbar: Identity<ToolbarInput | false>;
    forceEventDuration: BooleanConstructor;
    dayLaneClass: Identity<ClassNameGenerator<DayLaneInfo>>;
    dayLaneInnerClass: Identity<ClassNameGenerator<DayLaneInfo>>;
    dayLaneDidMount: Identity<DidMountHandler<DayLaneInfo>>;
    dayLaneWillUnmount: Identity<WillUnmountHandler<DayLaneInfo>>;
    initialView: StringConstructor;
    aspectRatio: NumberConstructor;
    weekends: BooleanConstructor;
    weekNumberCalculation: Identity<WeekNumberCalculation>;
    weekNumbers: BooleanConstructor;
    weekNumberHeaderClass: Identity<ClassNameGenerator<WeekNumberHeaderInfo>>;
    weekNumberHeaderInnerClass: Identity<ClassNameGenerator<WeekNumberHeaderInfo>>;
    weekNumberHeaderContent: Identity<ContentGenerator<WeekNumberHeaderInfo>>;
    weekNumberHeaderDidMount: Identity<DidMountHandler<WeekNumberHeaderInfo>>;
    weekNumberHeaderWillUnmount: Identity<WillUnmountHandler<WeekNumberHeaderInfo>>;
    inlineWeekNumberClass: Identity<ClassNameGenerator<InlineWeekNumberInfo>>;
    inlineWeekNumberContent: Identity<ContentGenerator<InlineWeekNumberInfo>>;
    inlineWeekNumberDidMount: Identity<DidMountHandler<InlineWeekNumberInfo>>;
    inlineWeekNumberWillUnmount: Identity<WillUnmountHandler<InlineWeekNumberInfo>>;
    editable: BooleanConstructor;
    controller: Identity<CalendarController>;
    nowIndicator: BooleanConstructor;
    nowIndicatorSnap: Identity<boolean | "auto">;
    nowIndicatorHeaderClass: Identity<ClassNameGenerator<NowIndicatorHeaderInfo>>;
    nowIndicatorHeaderContent: Identity<ContentGenerator<NowIndicatorHeaderInfo>>;
    nowIndicatorHeaderDidMount: Identity<DidMountHandler<NowIndicatorHeaderInfo>>;
    nowIndicatorHeaderWillUnmount: Identity<WillUnmountHandler<NowIndicatorHeaderInfo>>;
    nowIndicatorDotClass: typeof refineClassName;
    nowIndicatorLineClass: Identity<ClassNameGenerator<NowIndicatorLineInfo>>;
    nowIndicatorLineContent: Identity<ContentGenerator<NowIndicatorLineInfo>>;
    nowIndicatorLineDidMount: Identity<DidMountHandler<NowIndicatorLineInfo>>;
    nowIndicatorLineWillUnmount: Identity<WillUnmountHandler<NowIndicatorLineInfo>>;
    showNonCurrentDates: BooleanConstructor;
    lazyFetching: BooleanConstructor;
    startParam: StringConstructor;
    endParam: StringConstructor;
    timeZoneParam: StringConstructor;
    timeZone: StringConstructor;
    locales: Identity<LocaleInput[]>;
    locale: Identity<LocaleSingularArg>;
    dragRevertDuration: NumberConstructor;
    dragScroll: BooleanConstructor;
    allDayMaintainDuration: BooleanConstructor;
    unselectAuto: BooleanConstructor;
    dropAccept: Identity<string | ((this: CalendarApi, draggable: any) => boolean)>;
    eventOrder: typeof parseFieldSpecs;
    eventOrderStrict: BooleanConstructor;
    eventSlicing: BooleanConstructor;
    eventPrintLayout: Identity<"auto" | "stack" | "grid">;
    longPressDelay: NumberConstructor;
    eventDragMinDistance: NumberConstructor;
    expandRows: BooleanConstructor;
    height: Identity<CssDimValue>;
    contentHeight: Identity<CssDimValue>;
    direction: Identity<"ltr" | "rtl">;
    colorScheme: Identity<"light" | "dark" | string | undefined>;
    weekNumberFormat: typeof createFormatter;
    eventResizableFromStart: BooleanConstructor;
    displayEventTime: BooleanConstructor;
    displayEventEnd: BooleanConstructor;
    progressiveEventRendering: BooleanConstructor;
    businessHours: Identity<BusinessHoursInput>;
    initialDate: Identity<DateInput>;
    now: Identity<DateInput | ((this: CalendarApi) => DateInput)>;
    eventDataTransform: Identity<EventInputTransformer>;
    tableHeaderSticky: Identity<boolean | "auto">;
    footerScrollbarSticky: Identity<boolean | "auto">;
    defaultAllDay: BooleanConstructor;
    eventSourceFailure: Identity<(this: CalendarApi, error: any) => void>;
    eventSourceSuccess: Identity<(this: CalendarApi, eventsInput: EventInput[], response?: Response) => EventInput[] | void>;
    eventDisplay: StringConstructor;
    eventStartEditable: BooleanConstructor;
    eventDurationEditable: BooleanConstructor;
    eventOverlap: Identity<boolean | OverlapFunc>;
    eventConstraint: Identity<ConstraintInput>;
    eventAllow: Identity<AllowFunc>;
    eventColor: StringConstructor;
    eventContrastColor: StringConstructor;
    eventDidMount: Identity<DidMountHandler<EventDisplayInfo>>;
    eventWillUnmount: Identity<WillUnmountHandler<EventDisplayInfo>>;
    eventContent: Identity<ContentGenerator<EventDisplayInfo>>;
    eventClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    eventInnerClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    eventTimeClass: Identity<ClassNameGenerator<EventTextInfo>>;
    eventTitleClass: Identity<ClassNameGenerator<EventTextInfo>>;
    eventBeforeClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    eventAfterClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    listItemEventClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    listItemEventInnerClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    listItemEventTimeClass: Identity<ClassNameGenerator<EventTextInfo>>;
    listItemEventTitleClass: Identity<ClassNameGenerator<EventTextInfo>>;
    listItemEventBeforeClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    listItemEventAfterClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    blockEventClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    blockEventInnerClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    blockEventTimeClass: Identity<ClassNameGenerator<EventTextInfo>>;
    blockEventTitleClass: Identity<ClassNameGenerator<EventTextInfo>>;
    blockEventBeforeClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    blockEventAfterClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    rowEventClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    rowEventInnerClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    rowEventTimeClass: Identity<ClassNameGenerator<EventTextInfo>>;
    rowEventTitleClass: Identity<ClassNameGenerator<EventTextInfo>>;
    rowEventTitleSticky: BooleanConstructor;
    rowEventBeforeClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    rowEventBeforeContent: Identity<ContentGenerator<EventDisplayInfo>>;
    rowEventAfterClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    rowEventAfterContent: Identity<ContentGenerator<EventDisplayInfo>>;
    columnEventClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    columnEventInnerClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    columnEventTimeClass: Identity<ClassNameGenerator<EventTextInfo>>;
    columnEventTitleClass: Identity<ClassNameGenerator<EventTextInfo>>;
    columnEventTitleSticky: BooleanConstructor;
    columnEventBeforeClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    columnEventAfterClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    backgroundEventClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    backgroundEventDidMount: Identity<DidMountHandler<EventDisplayInfo>>;
    backgroundEventWillUnmount: Identity<WillUnmountHandler<EventDisplayInfo>>;
    backgroundEventContent: Identity<ContentGenerator<EventDisplayInfo>>;
    backgroundEventInnerClass: Identity<ClassNameGenerator<EventDisplayInfo>>;
    backgroundEventTitleClass: Identity<ClassNameGenerator<EventTextInfo>>;
    backgroundEventColor: StringConstructor;
    selectConstraint: Identity<ConstraintInput>;
    selectOverlap: Identity<boolean | OverlapFunc>;
    selectAllow: Identity<AllowFunc>;
    droppable: BooleanConstructor;
    unselectCancel: StringConstructor;
    slotHeaderFormat: Identity<FormatterInput | FormatterInput[]>;
    slotLaneClass: Identity<ClassNameGenerator<SlotLaneInfo>>;
    slotLaneDidMount: Identity<DidMountHandler<SlotLaneInfo>>;
    slotLaneWillUnmount: Identity<WillUnmountHandler<SlotLaneInfo>>;
    slotHeaderClass: Identity<ClassNameGenerator<SlotHeaderInfo>>;
    slotHeaderInnerClass: Identity<ClassNameGenerator<SlotHeaderInfo>>;
    slotHeaderContent: Identity<ContentGenerator<SlotHeaderInfo>>;
    slotHeaderDidMount: Identity<DidMountHandler<SlotHeaderInfo>>;
    slotHeaderWillUnmount: Identity<WillUnmountHandler<SlotHeaderInfo>>;
    slotHeaderAlign: Identity<"start" | "center" | "end" | ((info: {
        level: number;
        isTime: boolean;
    }) => "start" | "center" | "end")>;
    slotHeaderSticky: Identity<boolean | number | string>;
    slotHeaderRowClass: typeof refineClassName;
    slotHeaderDividerClass: Identity<ClassNameGenerator<{
        inTableHeader: boolean;
        options: {
            dayMinWidth: number | undefined;
        };
    }>>;
    dayMaxEvents: Identity<boolean | number>;
    dayMaxEventRows: Identity<boolean | number>;
    dayMinWidth: NumberConstructor;
    slotHeaderInterval: typeof createDuration;
    dayHeaderClass: Identity<ClassNameGenerator<DayHeaderInfo>>;
    dayHeaderInnerClass: Identity<ClassNameGenerator<DayHeaderInfo>>;
    dayHeaderContent: Identity<ContentGenerator<DayHeaderInfo>>;
    dayHeaderDidMount: Identity<DidMountHandler<DayHeaderInfo>>;
    dayHeaderWillUnmount: Identity<WillUnmountHandler<DayHeaderInfo>>;
    dayHeaderAlign: Identity<"start" | "center" | "end" | ((info: {
        level: number;
        inPopover: boolean;
        isNarrow: boolean;
    }) => "start" | "center" | "end")>;
    _dayHeaderSticky: Identity<boolean | number | string>;
    dayHeaderRowClass: typeof refineClassName;
    dayHeaderDividerClass: Identity<ClassNameGenerator<DayHeaderDividerInfo>>;
    dayRowClass: typeof refineClassName;
    dayCellDidMount: Identity<DidMountHandler<DayCellInfo>>;
    dayCellWillUnmount: Identity<WillUnmountHandler<DayCellInfo>>;
    dayCellClass: Identity<ClassNameGenerator<DayCellInfo>>;
    dayCellInnerClass: Identity<ClassNameGenerator<DayCellInfo>>;
    dayCellTopContent: Identity<ContentGenerator<DayCellInfo>>;
    dayCellTopClass: Identity<ClassNameGenerator<DayCellInfo>>;
    dayCellTopInnerClass: Identity<ClassNameGenerator<DayCellInfo>>;
    dayCellBottomClass: Identity<ClassNameGenerator<DayCellInfo>>;
    allDaySlot: BooleanConstructor;
    allDayText: StringConstructor;
    allDayHeaderClass: Identity<ClassNameGenerator<AllDayHeaderInfo>>;
    allDayHeaderInnerClass: Identity<ClassNameGenerator<AllDayHeaderInfo>>;
    allDayHeaderContent: Identity<ContentGenerator<AllDayHeaderInfo>>;
    allDayHeaderDidMount: Identity<DidMountHandler<AllDayHeaderInfo>>;
    allDayHeaderWillUnmount: Identity<WillUnmountHandler<AllDayHeaderInfo>>;
    timedText: StringConstructor;
    slotMinWidth: NumberConstructor;
    slotMinHeight: NumberConstructor;
    navLinks: BooleanConstructor;
    eventTimeFormat: typeof createFormatter;
    rerenderDelay: NumberConstructor;
    moreLinkText: Identity<string | ((this: CalendarApi, num: number) => string)>;
    moreLinkHint: Identity<string | ((this: CalendarApi, num: number) => string)>;
    selectMinDistance: NumberConstructor;
    selectable: BooleanConstructor;
    selectLongPressDelay: NumberConstructor;
    eventLongPressDelay: NumberConstructor;
    selectMirror: BooleanConstructor;
    eventMaxStack: NumberConstructor;
    eventMinHeight: NumberConstructor;
    eventMinWidth: NumberConstructor;
    eventShortHeight: NumberConstructor;
    slotEventOverlap: BooleanConstructor;
    firstDay: NumberConstructor;
    dayCount: NumberConstructor;
    dateAlignment: StringConstructor;
    dateIncrement: typeof createDuration;
    hiddenDays: Identity<number[]>;
    fixedWeekCount: BooleanConstructor;
    validRange: Identity<DateRangeInput | ((this: CalendarApi, nowDate: Date) => DateRangeInput)>;
    visibleRange: Identity<DateRangeInput | ((this: CalendarApi, currentDate: Date) => DateRangeInput)>;
    titleFormat: Identity<FormatterInput>;
    eventInteractive: BooleanConstructor;
    noEventsText: StringConstructor;
    viewHint: Identity<string | ((viewButtonText: string, viewName: string) => string)>;
    viewChangeHint: StringConstructor;
    navLinkHint: Identity<string | ((dateText: string, date: Date) => string)>;
    closeHint: StringConstructor;
    eventsHint: StringConstructor;
    headingLevel: NumberConstructor;
    moreLinkClick: Identity<MoreLinkAction>;
    moreLinkContent: Identity<ContentGenerator<MoreLinkInfo$1>>;
    moreLinkDidMount: Identity<DidMountHandler<MoreLinkInfo$1>>;
    moreLinkWillUnmount: Identity<WillUnmountHandler<MoreLinkInfo$1>>;
    moreLinkClass: Identity<ClassNameGenerator<MoreLinkInfo$1>>;
    moreLinkInnerClass: Identity<ClassNameGenerator<MoreLinkInfo$1>>;
    rowMoreLinkClass: Identity<ClassNameGenerator<MoreLinkInfo$1>>;
    rowMoreLinkInnerClass: Identity<ClassNameGenerator<MoreLinkInfo$1>>;
    columnMoreLinkClass: Identity<ClassNameGenerator<MoreLinkInfo$1>>;
    columnMoreLinkInnerClass: Identity<ClassNameGenerator<MoreLinkInfo$1>>;
    navLinkClass: typeof refineClassName;
    monthStartFormat: typeof createFormatter;
    dayCellFormat: typeof createFormatter;
    handleCustomRendering: Identity<CustomRenderingHandler<any>>;
    customRenderingMetaMap: Identity<{
        [optionName: string]: any;
    }>;
    popoverClass: typeof refineClassName;
    popoverCloseClass: typeof refineClassName;
    popoverCloseContent: Identity<ContentGenerator<{}>>;
    dayNarrowWidth: NumberConstructor;
    borderless: BooleanConstructor;
    borderlessX: BooleanConstructor;
    borderlessTop: BooleanConstructor;
    borderlessBottom: BooleanConstructor;
    fillerClass: Identity<ClassNameGenerator<{
        inTableHeader: boolean;
    }>>;
    headerToolbarClass: Identity<ClassNameGenerator<ToolbarInfo>>;
    footerToolbarClass: Identity<ClassNameGenerator<ToolbarInfo>>;
    toolbarClass: Identity<ClassNameGenerator<ToolbarInfo>>;
    toolbarSectionClass: Identity<ClassNameGenerator<ToolbarSectionInfo>>;
    toolbarTitleClass: typeof refineClassName;
    tableClass: Identity<ClassNameGenerator<TableDisplayInfo>>;
    tableHeaderClass: Identity<ClassNameGenerator<TableHeaderInfo>>;
    tableBodyClass: Identity<ClassNameGenerator<TableBodyInfo>>;
    nonBusinessHoursClass: typeof refineClassName;
    highlightClass: typeof refineClassName;
    dayHeaders: BooleanConstructor;
    dayHeaderFormat: typeof createFormatter;
    allDayDividerClass: typeof refineClassName;
    listDaysClass: typeof refineClassName;
    listDayClass: Identity<ClassNameGenerator<ListDayInfo>>;
    listDayFormat: typeof createFalsableFormatter;
    listDayAltFormat: typeof createFalsableFormatter;
    listDayHeaderDidMount: Identity<DidMountHandler<ListDayHeaderInfo>>;
    listDayHeaderWillUnmount: Identity<WillUnmountHandler<ListDayHeaderInfo>>;
    listDayHeaderClass: Identity<ClassNameGenerator<ListDayHeaderInfo>>;
    listDayHeaderInnerClass: Identity<ClassNameGenerator<ListDayHeaderInnerInfo>>;
    listDayHeaderContent: Identity<ContentGenerator<ListDayHeaderInnerInfo>>;
    listDayBodyClass: Identity<ClassNameGenerator<ListDayEventsInfo>>;
    noEventsClass: Identity<ClassNameGenerator<NoEventsInfo>>;
    noEventsInnerClass: Identity<ClassNameGenerator<NoEventsInfo>>;
    noEventsContent: Identity<ContentGenerator<NoEventsInfo>>;
    noEventsDidMount: Identity<DidMountHandler<NoEventsInfo>>;
    noEventsWillUnmount: Identity<WillUnmountHandler<NoEventsInfo>>;
    multiMonthMaxColumns: NumberConstructor;
    singleMonthMinWidth: NumberConstructor;
    singleMonthTitleFormat: typeof createFormatter;
    singleMonthDidMount: Identity<DidMountHandler<SingleMonthInfo>>;
    singleMonthWillUnmount: Identity<WillUnmountHandler<SingleMonthInfo>>;
    singleMonthClass: Identity<ClassNameGenerator<SingleMonthInfo>>;
    singleMonthHeaderClass: Identity<ClassNameGenerator<SingleMonthHeaderInfo>>;
    singleMonthHeaderInnerClass: Identity<ClassNameGenerator<SingleMonthHeaderInfo>>;
};
type BaseOptionRefiners = typeof BASE_OPTION_REFINERS;
declare module '@fullcalendar/core/protected-api' {
    interface BaseOptions extends RawOptionsFromRefiners<BaseOptionRefiners> {
    }
    interface BaseOptionsRefined extends RefinedOptionsFromRefiners<BaseOptionRefiners> {
    }
}
declare const CALENDAR_LISTENER_REFINERS: {
    datesSet: Identity<(info: DatesSetInfo) => void>;
    eventsSet: Identity<(events: EventApi[]) => void>;
    eventAdd: Identity<(info: EventAddInfo) => void>;
    eventChange: Identity<(info: EventChangeInfo) => void>;
    eventRemove: Identity<(info: EventRemoveInfo) => void>;
    eventClick: Identity<(info: EventClickInfo) => void>;
    eventMouseEnter: Identity<(info: EventHoveringInfo) => void>;
    eventMouseLeave: Identity<(info: EventHoveringInfo) => void>;
    select: Identity<(info: DateSelectInfo) => void>;
    unselect: Identity<(info: DateUnselectInfo) => void>;
    loading: Identity<(isLoading: boolean) => void>;
    _unmount: Identity<() => void>;
    _beforeprint: Identity<() => void>;
    _afterprint: Identity<() => void>;
    _noDateSelect: Identity<() => void>;
    _noEventDrop: Identity<() => void>;
    _noEventResize: Identity<() => void>;
    _timeScrollRequest: Identity<(time: Duration) => void>;
    dateClick: Identity<(info: DateClickInfo) => void>;
    eventDragStart: Identity<(info: EventDragStartInfo) => void>;
    eventDragStop: Identity<(info: EventDragStopInfo) => void>;
    eventDrop: Identity<(info: EventDropInfo) => void>;
    eventResizeStart: Identity<(info: EventResizeStartInfo) => void>;
    eventResizeStop: Identity<(info: EventResizeStopInfo) => void>;
    eventResize: Identity<(info: EventResizeDoneInfo) => void>;
    drop: Identity<(info: DropInfo) => void>;
    eventReceive: Identity<(info: EventReceiveInfo) => void>;
    eventLeave: Identity<(info: EventLeaveInfo) => void>;
};
type CalendarListenerRefiners = typeof CALENDAR_LISTENER_REFINERS;
interface CalendarListeners extends RawOptionsFromRefiners<CalendarListenerRefiners> {
}
interface CalendarListenersRefined extends RefinedOptionsFromRefiners<CalendarListenerRefiners> {
}
declare const CALENDAR_ONLY_OPTION_REFINERS: {
    class: Identity<ClassNameGenerator<CalendarDisplayInfo>>;
    className: Identity<ClassNameGenerator<CalendarDisplayInfo>>;
    viewClass: Identity<ClassNameGenerator<ViewDisplayInfo>>;
    viewDidMount: Identity<DidMountHandler<ViewDisplayInfo>>;
    viewWillUnmount: Identity<WillUnmountHandler<ViewDisplayInfo>>;
    views: Identity<{
        [viewId: string]: ViewOptions;
    }>;
    plugins: Identity<PluginInput[]>;
    initialEvents: Identity<EventSourceInput>;
    events: Identity<EventSourceInput>;
    eventSources: Identity<EventSourceInput[]>;
};
type CalendarOnlyOptionRefiners = typeof CALENDAR_ONLY_OPTION_REFINERS;
type CalendarOnlyOptions = RawOptionsFromRefiners<CalendarOnlyOptionRefiners>;
type CalendarOnlyOptionsRefined = RefinedOptionsFromRefiners<CalendarOnlyOptionRefiners>;
declare const VIEW_ONLY_OPTION_REFINERS: {
    type: StringConstructor;
    component: Identity<ViewComponentType>;
    class: Identity<ClassNameGenerator<ViewDisplayInfo>>;
    className: Identity<ClassNameGenerator<ViewDisplayInfo>>;
    content: Identity<ContentGenerator<ViewContentInfo>>;
    didMount: Identity<DidMountHandler<ViewDisplayInfo>>;
    willUnmount: Identity<WillUnmountHandler<ViewDisplayInfo>>;
    buttonTextKey: StringConstructor;
    dateProfileGeneratorClass: Identity<DateProfileGeneratorClass>;
    usesMinMaxTime: BooleanConstructor;
    disallowAmbigTitle: BooleanConstructor;
};
type ViewOnlyRefiners = typeof VIEW_ONLY_OPTION_REFINERS;
type ViewOnlyOptions = RawOptionsFromRefiners<ViewOnlyRefiners>;
type ViewOnlyOptionsRefined = RefinedOptionsFromRefiners<ViewOnlyRefiners>;
type ViewOptions = BaseOptions & CalendarListeners & ViewOnlyOptions;
type ViewOptionsRefined = BaseOptionsRefined & CalendarListenersRefined & ViewOnlyOptionsRefined;
type CalendarOptions = BaseOptions & CalendarListeners & CalendarOnlyOptions;
type CalendarOptionsRefined = BaseOptionsRefined & CalendarListenersRefined & CalendarOnlyOptionsRefined;
declare function refineProps<Refiners extends GenericRefiners, Raw extends RawOptionsFromRefiners<Refiners>>(input: Raw, refiners: Refiners): {
    refined: RefinedOptionsFromRefiners<Refiners>;
    extra: Dictionary;
};
type GenericRefiners = {
    [propName: string]: (input: any, propName: string) => any;
};
type GenericListenerRefiners = {
    [listenerName: string]: Identity<(this: CalendarApi, ...args: any[]) => void>;
};
type Dictionary = Record<string, any>;
type Identity<T = any> = (raw: T) => T;
declare function identity<T>(raw: T): T;
declare function createFalsableFormatter(input: FormatterInput | false): DateFormatter;

type LocaleSingularArg = LocaleCodeArg | LocaleInput;
interface LocaleInput extends CalendarOptions {
    code: string;
}

export { ButtonInput as $, AllowFunc as A, BusinessHoursInput as B, CalendarController as C, DateSpanInput as D, EventSourceApi as E, DayHeaderDividerInfo as F, DayCellInfo as G, DayLaneInfo as H, InlineWeekNumberInfo as I, ViewDisplayInfo as J, TableBodyInfo as K, LocaleInput as L, MountInfo as M, NowIndicatorHeaderInfo as N, OverlapFunc as O, PluginInput as P, TableHeaderInfo as Q, CalendarDisplayInfo as R, SlotLaneInfo as S, TableDisplayInfo as T, EventClickInfo as U, ViewApi as V, WillUnmountHandler as W, EventHoveringInfo as X, DateSelectInfo as Y, DateUnselectInfo as Z, ToolbarInput as _, CalendarApi as a, EventDef as a$, ButtonGroupInfo as a0, ButtonInfo as a1, ButtonDisplay as a2, ToolbarElementInput as a3, ToolbarSectionInfo as a4, ToolbarInfo as a5, EventDisplayInfo as a6, EventTextInfo as a7, ViewContentInfo as a8, DatesSetInfo as a9, EventResizeStartInfo as aA, EventResizeStopInfo as aB, EventResizeDoneInfo as aC, DateClickInfo as aD, DropInfo as aE, EventReceiveInfo as aF, EventLeaveInfo as aG, Dictionary as aH, valuesIdentical as aI, ViewContext as aJ, DateProfileGenerator as aK, DateProfile as aL, Emitter as aM, DateComponent as aN, ScrollerInterface as aO, EventRangeProps as aP, EventSegUiInteractionState as aQ, DateSpan as aR, CalendarContext as aS, EventStore as aT, EventInteractionState as aU, EventUiHash as aV, SplittableProps as aW, BaseComponent as aX, ElRef as aY, ViewOptionsRefined as aZ, Splitter as a_, EventAddInfo as aa, EventChangeInfo as ab, EventDropInfo as ac, EventRemoveInfo as ad, CustomRenderingHandler as ae, CustomRenderingStore as af, DateSpanApi as ag, DatePointApi as ah, DateSelectionApi as ai, ButtonState as aj, NavButtonState as ak, ButtonStateMap as al, FormatterInput as am, LocaleSingularArg as an, NoEventsInfo as ao, ListDayHeaderInfo as ap, ListDayHeaderInnerInfo as aq, ListDayInfo as ar, SingleMonthInfo as as, SingleMonthHeaderInfo as at, EventSegment as au, MoreLinkAction as av, MoreLinkSimpleAction as aw, MoreLinkHandler as ax, EventDragStartInfo as ay, EventDragStopInfo as az, EventApi as b, CustomRendering as b$, DateMeta as b0, Hit as b1, CalendarListenersRefined as b2, Identity as b3, identity as b4, refineProps as b5, EventDefHash as b6, EventInstanceHash as b7, EventInstanceRange as b8, EventRangeEdge as b9, ViewPropsTransformer as bA, Action as bB, CalendarContentProps as bC, CalendarInner as bD, sortEventSegs as bE, getEventRangeMeta as bF, buildEventRangeKey as bG, MinimalEventProps as bH, EventMutation as bI, Constraint as bJ, setRef as bK, getFooterScrollbarSticky as bL, getTableHeaderSticky as bM, getIsHeightAuto as bN, ScrollerSyncerInterface as bO, refineClassName as bP, refineClassNameGenerator as bQ, NowIndicatorHeaderContainer as bR, NowIndicatorLineContainer as bS, MoreLinkContainer as bT, ViewContainer as bU, CalendarApiImpl as bV, EventImpl as bW, CalendarMediaRoot as bX, computeRootClassName as bY, ContentContainer as bZ, generateClassName as b_, buildValidInstanceRange as ba, getRangeInstantStartMs as bb, getRangeInstantEndMs as bc, EventRefined as bd, parseBusinessHours as be, OrderSpec as bf, parseFieldSpecs as bg, compareByFieldSpecs as bh, flexibleCompare as bi, guid as bj, computeViewBorderless as bk, getRectCenter as bl, mergeEventStores as bm, EventUi as bn, combineEventUis as bo, createEventUi as bp, getDateMeta as bq, CalendarData as br, CalendarDataManager as bs, ViewProps as bt, computeMajorUnit as bu, isMajorUnit as bv, getDateSpanInstantStartMs as bw, getDateSpanInstantEndMs as bx, PointerDragEvent as by, ElementDragging as bz, EventRenderRange as c, createFormatter as c0, Rect as c1, DragMetaInput as c2, CalendarOptions as d, CalendarListeners as e, ViewOptions as f, EventSourceInput as g, EventSourceFunc as h, EventSourceFuncInfo as i, EventInput as j, EventInputTransformer as k, CssDimValue as l, ConstraintInput as m, ViewComponentType as n, ClassNameInput as o, ClassNameGenerator as p, ContentGenerator as q, DidMountHandler as r, sliceEvents as s, NowIndicatorLineInfo as t, WeekNumberHeaderInfo as u, DateTimeFormatPartWithWeek as v, MoreLinkInfo$1 as w, SlotHeaderInfo as x, AllDayHeaderInfo as y, DayHeaderInfo as z };
