import { jsx } from 'react/jsx-runtime';
import React, { forwardRef, useState, useEffect, useImperativeHandle } from 'react';
import { flushSync } from 'react-dom';
import { C as CalendarApiImpl, a as CalendarDataManager, b as CalendarMediaRoot, c as computeRootClassName, d as CalendarInner } from './867bc55f.js';
import { g as guid, w as warn } from './6e87ff0f.js';

const Calendar = forwardRef((props, ref) => {
    const baseId = useStableId(props.id); // for DOM ids
    const [_revision, setRevision] = useState('');
    function handleDataChange(_data, actions) {
        (needsSyncRender(actions) ? flushSync : runNormal)(() => {
            setRevision(guid());
        });
    }
    const [calendarApi] = useState(() => new CalendarApiImpl());
    const [calendarDataManager] = useState(() => new CalendarDataManager({
        calendarApi,
        onDataChange: handleDataChange,
    }));
    useEffect(() => {
        return () => {
            calendarDataManager.destroy();
        };
    }, []);
    useImperativeHandle(ref, () => ({
        getApi: () => calendarApi
    }), []);
    const data = calendarDataManager.update(props);
    return (jsx(CalendarMediaRoot, { emitter: data.emitter, children: (forPrint) => {
            const options = data.calendarOptions;
            const isRtl = options.direction === 'rtl';
            const className = computeRootClassName(options, forPrint);
            return (jsx("div", { dir: isRtl ? 'rtl' : undefined, className: className, style: { height: options.height }, "data-color-scheme": options.colorScheme || undefined, children: jsx(CalendarInner, { ...data, baseId: baseId, forPrint: forPrint }) }));
        } }));
});
function needsSyncRender(actions) {
    for (const action of actions) {
        if (action.type === 'SET_EVENT_DRAG' ||
            action.type === 'UNSET_EVENT_DRAG' ||
            action.type === 'SET_EVENT_RESIZE' ||
            action.type === 'UNSET_EVENT_RESIZE' ||
            // could happen as a result of a drag or resize and must be part of same sync pipeline
            action.type === 'MERGE_EVENTS') {
            return true;
        }
    }
    return false;
}
function runNormal(f) {
    f();
}
let warnedStableId = false;
function useStableId(fallbackId) {
    // React >= 18
    // During runtime, will not change
    if (React.useId) {
        return React.useId();
    }
    // Must always execute, regardless of fallbackId, because of hook rules
    const [uid] = useState(() => guid());
    if (fallbackId) {
        return fallbackId + ':';
    }
    if (!warnedStableId) {
        warnedStableId = true;
        warn('Missing `id` prop. Provide one for better SSR support in React 17.');
    }
    return `fc:${uid}:`;
}

export { Calendar as C };
