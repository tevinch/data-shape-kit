import { N as NowTimerRunner, V as ViewContextType, B as BaseComponent, b as memoizeObjArg, g as getIsHeightAuto, C as ContentContainer, a as generateClassName, s as setRef, e as watchWidth, w as watchHeight, m as memoize } from './ad0714f5.js';
import { Component } from 'react';
import { joinDateTimeFormatParts, rangeContainsMarker } from '@full-ui/headless-calendar';
import { j as joinClassNames } from './ebfc0d8f.js';
import { c as createFormatter, l as formatWithOrdinals, ai as createAriaClickAttrs, k as computeViewBorderless, g as guid, z as EventImpl, aj as setElEventRange, ak as buildEventRangeTimeText, al as getEventTagAndAttrs, am as computeEventRangeDraggable, u as isPropsEqualShallow } from './6e87ff0f.js';
import { c as classNames } from './e8f6e367.js';
import { jsx, jsxs, Fragment } from 'react/jsx-runtime';
import { c as computeElIsRtl } from './3885230d.js';
import { E as Emitter } from './2649389b.js';

class NowTimer extends Component {
    constructor(props, context) {
        super(props, context);
        this.handleChange = () => {
            this.forceUpdate();
        };
        this.runner = new NowTimerRunner(this.handleChange);
    }
    render() {
        const { props, context } = this;
        const { nowDate, nowMs, todayRange } = this.runner.update({
            nowManager: context.nowManager,
            unit: props.unit,
            unitValue: props.unitValue,
            nowIndicatorSnap: context.options.nowIndicatorSnap,
            dateEnv: context.dateEnv,
        });
        return props.children(nowDate, todayRange, nowMs);
    }
    componentWillUnmount() {
        this.runner.destroy();
    }
}
NowTimer.contextType = ViewContextType;

const FULL_DATE_FORMAT = createFormatter({ year: 'numeric', month: 'long', day: 'numeric' });
const WEEK_FORMAT = createFormatter({ week: 'long' });
const WEEKDAY_ONLY_FORMAT = createFormatter({
    weekday: 'long',
});
function findWeekdayText(parts) {
    for (const part of parts) {
        if (part.type === 'weekday') {
            return part.value;
        }
    }
    return '';
}
function findDayNumberText(parts) {
    for (const part of parts) {
        if (part.type === 'day') {
            return part.value;
        }
    }
    return '';
}
function findMonthText(parts) {
    for (const part of parts) {
        if (part.type === 'month') {
            return part.value;
        }
    }
    return '';
}

/*
TODO: just have this return the string?
*/
function buildDateStr(context, dateMarker, viewType = 'day') {
    return joinDateTimeFormatParts(context.dateEnv.formatToParts(dateMarker, viewType === 'week' ? WEEK_FORMAT : FULL_DATE_FORMAT));
}
/*
Assumes navLinks enabled
Always hidden to screen readers. Do not point aria-labelledby at this. Use aria-label instead.
*/
function buildNavLinkAttrs(context, dateMarker, viewType = 'day', dateStr = buildDateStr(context, dateMarker, viewType), isTabbable = true, 
// for column headers: the label becomes the column's name, read for every cell in the column, and
// screen readers already say "link". so it's just the date, without navLinkHint ("Go to $0")
omitHint = false) {
    const { dateEnv, options, calendarApi } = context;
    const zonedDate = dateEnv.toDate(dateMarker);
    const handleInteraction = (ev) => {
        let customAction = viewType === 'day' ? options.navLinkDayClick :
            viewType === 'week' ? options.navLinkWeekClick : null;
        if (typeof customAction === 'function') {
            customAction.call(calendarApi, dateEnv.toDate(dateMarker), ev);
        }
        else {
            if (typeof customAction === 'string') {
                viewType = customAction;
            }
            calendarApi.zoomTo(dateMarker, viewType);
        }
    };
    return {
        'role': 'link', // TODO
        'aria-label': omitHint ? dateStr : formatWithOrdinals(options.navLinkHint, [dateStr, zonedDate], dateStr),
        'className': joinClassNames(options.navLinkClass, classNames.cursorPointer, classNames.internalNavLink),
        ...(isTabbable
            ? createAriaClickAttrs(handleInteraction)
            : { onClick: handleInteraction }),
    };
}

function getDateMeta(dateMarker, dateEnv, dateProfile, todayRange, nowDate) {
    const isDisabled = Boolean(dateProfile && (!dateProfile.activeRange || !rangeContainsMarker(dateProfile.activeRange, dateMarker)));
    return {
        date: dateEnv.toDate(dateMarker),
        dow: dateMarker.getUTCDay(),
        isDisabled,
        isOther: !isDisabled && Boolean(dateProfile && !rangeContainsMarker(dateProfile.currentRange, dateMarker)),
        isToday: !isDisabled && Boolean(todayRange && rangeContainsMarker(todayRange, dateMarker)),
        isPast: !isDisabled && Boolean(nowDate ? (dateMarker < nowDate) : todayRange ? (dateMarker < todayRange.start) : false),
        isFuture: !isDisabled && Boolean(nowDate ? (dateMarker > nowDate) : todayRange ? (dateMarker >= todayRange.end) : false),
    };
}

class ViewContainer extends BaseComponent {
    constructor() {
        super(...arguments);
        this.refineRenderProps = memoizeObjArg(refineRenderProps);
    }
    render() {
        const { props, context } = this;
        const { options, viewSpec } = context;
        const renderProps = this.refineRenderProps({
            ...computeViewBorderless(options),
            options: { headerToolbar: options.headerToolbar, footerToolbar: options.footerToolbar },
            isHeightAuto: getIsHeightAuto(options),
            viewApi: context.viewApi,
        });
        return (jsx(ContentContainer, { elRef: props.elRef, tag: props.tag || 'div', attrs: props.attrs, style: props.style, className: joinClassNames(props.className, generateClassName(options.viewClass, renderProps), 
            // WORKAROUND for way calendar's className would get merged into view's className
            generateClassName(viewSpec.optionDefaults.class, renderProps), generateClassName(viewSpec.optionDefaults.className, renderProps), generateClassName(viewSpec.optionOverrides.class, renderProps), generateClassName(viewSpec.optionOverrides.className, renderProps)), renderProps: renderProps, generatorName: undefined, didMount: options.didMount || options.viewDidMount, willUnmount: options.willUnmount || options.viewWillUnmount, children: () => props.children }));
    }
}
function refineRenderProps(raw) {
    return {
        view: raw.viewApi,
        borderlessX: raw.borderlessX,
        borderlessTop: raw.borderlessTop,
        borderlessBottom: raw.borderlessBottom,
        options: raw.options,
        isHeightAuto: raw.isHeightAuto,
    };
}

/*
an INTERACTABLE date component

PURPOSES:
- hook up to fg, fill, and mirror renderers
- interface for dragging and hits
*/
class DateComponent extends BaseComponent {
    constructor() {
        super(...arguments);
        this.uid = guid();
    }
    // Hit System
    // -----------------------------------------------------------------------------------------------------------------
    prepareHits() {
    }
    queryHit(isRtl, positionLeft, positionTop, elWidth, elHeight) {
        return null; // this should be abstract
    }
    // Pointer Interaction Utils
    // -----------------------------------------------------------------------------------------------------------------
    isValidSegDownEl(el) {
        return !this.props.eventDrag && // HACK
            !this.props.eventResize && // HACK
            !el.closest(`.${classNames.internalEventMirror}`);
    }
    isValidDateDownEl(el) {
        return !el.closest(`.${classNames.internalEvent}:not(.${classNames.internalBgEvent})`) &&
            !el.closest(`.${classNames.internalMoreLink}`) &&
            !el.closest(`.${classNames.internalNavLink}`) &&
            !el.closest(`.${classNames.internalPopover}`); // hack
    }
}

class DelayedRunner {
    constructor(drainedOption) {
        this.drainedOption = drainedOption;
        this.isRunning = false;
        this.isDirty = false;
        this.pauseDepths = {};
        this.timeoutId = 0;
    }
    request(delay) {
        this.isDirty = true;
        if (!this.isPaused()) {
            this.clearTimeout();
            if (delay == null) {
                this.tryDrain();
            }
            else {
                this.timeoutId = setTimeout(// NOT OPTIMAL! TODO: look at debounce
                this.tryDrain.bind(this), delay);
            }
        }
    }
    pause(scope = '') {
        let { pauseDepths } = this;
        pauseDepths[scope] = (pauseDepths[scope] || 0) + 1;
        this.clearTimeout();
    }
    resume(scope = '', force) {
        let { pauseDepths } = this;
        if (scope in pauseDepths) {
            if (force) {
                delete pauseDepths[scope];
            }
            else {
                pauseDepths[scope] -= 1;
                let depth = pauseDepths[scope];
                if (depth <= 0) {
                    delete pauseDepths[scope];
                }
            }
            this.tryDrain();
        }
    }
    isPaused() {
        return Object.keys(this.pauseDepths).length;
    }
    tryDrain() {
        if (!this.isRunning && !this.isPaused()) {
            this.isRunning = true;
            while (this.isDirty) {
                this.isDirty = false;
                this.drained(); // might set isDirty to true again
            }
            this.isRunning = false;
        }
    }
    clear() {
        this.clearTimeout();
        this.isDirty = false;
        this.pauseDepths = {};
    }
    clearTimeout() {
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
            this.timeoutId = 0;
        }
    }
    drained() {
        if (this.drainedOption) {
            this.drainedOption();
        }
    }
}

/*
NOTE: detection is complicated (w/ touch and wheel) because ScrollerSyncer needs to know about it,
but are we sure we can't just ignore programmatic scrollTo() calls with a flag? and determine the
the scroll-master simply by who was the newest scroller? Does passive:true do things asynchronously?
*/
class ScrollListener {
    constructor(el) {
        this.el = el;
        this.emitter = new Emitter();
        this.isScroll = false;
        this.isScrollRecent = false;
        this.isWheelRecent = false;
        this.isMouseDown = false; // user currently has mouse down?
        this.isTouchDown = false; // user currently has finger down?
        // accumulated during scroll
        this.isMouse = false;
        this.isTouch = false;
        this.isWheel = false;
        // Handlers
        // ----------------------------------------------------------------------------------------------
        this.handleScroll = () => {
            this.isScrollRecent = true;
            if (this.isMouseDown) {
                this.isMouse = true;
            }
            if (this.isTouchDown) {
                this.isTouch = true;
            }
            if (this.isWheelRecent) {
                this.isWheel = true;
            }
            this.startScroll();
            this.emitter.trigger('scroll', this.getIsDevice());
            this.scrollWaiter.request(500);
        };
        this.handleScrollWait = () => {
            this.isScrollRecent = false;
            // only end the scroll if not currently touching.
            // if touching, the scrolling will end later, on touchend.
            if (!this.isTouchDown) {
                this.endScroll();
            }
        };
        // will fire *before* the scroll event is fired (might not cause a scroll!)
        this.handleWheel = () => {
            this.isWheelRecent = true;
            this.wheelWaiter.request(500);
        };
        this.handleWheelWait = () => {
            this.isWheelRecent = false;
        };
        this.handleMouseDown = () => {
            this.isMouseDown = true;
        };
        this.handleMouseUp = () => {
            this.isMouseDown = false;
        };
        // will fire *before* the scroll event is fired (might not cause a scroll!)
        this.handleTouchStart = () => {
            this.isTouchDown = true;
        };
        this.handleTouchEnd = () => {
            this.isTouchDown = false;
            // if the user ended their touch, and the scroll area wasn't moving,
            // we consider this to be the end of the scroll
            // otherwise, wait for inertia to finish and handleScrollWait to fire
            if (!this.isScrollRecent) {
                this.endScroll();
            }
        };
        this.wheelWaiter = new DelayedRunner(this.handleWheelWait);
        this.scrollWaiter = new DelayedRunner(this.handleScrollWait);
        el.addEventListener('scroll', this.handleScroll, { passive: true });
        el.addEventListener('wheel', this.handleWheel, { passive: true });
        el.addEventListener('mousedown', this.handleMouseDown);
        el.addEventListener('mouseup', this.handleMouseUp);
        el.addEventListener('touchstart', this.handleTouchStart, { passive: true });
        el.addEventListener('touchend', this.handleTouchEnd);
    }
    destroy() {
        let { el } = this;
        el.removeEventListener('scroll', this.handleScroll, { passive: true });
        el.removeEventListener('wheel', this.handleWheel, { passive: true });
        el.removeEventListener('mousedown', this.handleMouseDown);
        el.removeEventListener('mouseup', this.handleMouseUp);
        el.removeEventListener('touchstart', this.handleTouchStart, { passive: true });
        el.removeEventListener('touchend', this.handleTouchEnd);
    }
    // Start / Stop
    // ----------------------------------------------------------------------------------------------
    startScroll() {
        if (!this.isScroll) {
            this.isScroll = true;
            this.emitter.trigger('scrollStart', this.getIsDevice());
        }
    }
    endScroll() {
        if (this.isScroll) { // extra protection because might be called publicly
            this.scrollWaiter.clear(); // (same)
            this.wheelWaiter.clear(); // (same)
            this.isScroll = false;
            this.isWheelRecent = false;
            this.emitter.trigger('scrollEnd', this.getIsDevice());
            this.isMouse = false;
            this.isTouch = false;
            this.isWheel = false;
        }
    }
    getIsDevice() {
        return this.isWheel || this.isMouse || this.isTouch;
    }
}

class Scroller extends DateComponent {
    constructor() {
        super(...arguments);
        this.handleEl = (el) => {
            if (this.el) {
                this.el = null;
                this._isUnmounting = true;
                this.listener.destroy();
            }
            if (el) {
                this.el = el;
                this._isUnmounting = false;
                this.listener = new ScrollListener(el);
            }
        };
        this.handleHRuler = (el) => {
            if (this.disconnectHRuler) {
                this.disconnectHRuler();
                this.disconnectHRuler = undefined;
                if (this.clientWidth !== undefined) {
                    this.clientWidth = undefined;
                    setRef(this.props.clientWidthRef, null);
                }
            }
            if (el) {
                this.disconnectHRuler = watchWidth(el, (clientWidth) => {
                    if (this._isUnmounting)
                        return;
                    if (clientWidth !== this.clientWidth) {
                        this.clientWidth = clientWidth;
                        setRef(this.props.clientWidthRef, clientWidth);
                    }
                });
            }
        };
        this.handleVRuler = (el) => {
            if (this.disconnectVRuler) {
                this.disconnectVRuler();
                this.disconnectVRuler = undefined;
                if (this.clientHeight !== undefined) {
                    this.clientHeight = undefined;
                    setRef(this.props.clientHeightRef, null);
                }
            }
            if (el) {
                this.disconnectVRuler = watchHeight(el, (clientHeight) => {
                    if (this._isUnmounting)
                        return;
                    if (clientHeight !== this.clientHeight) {
                        this.clientHeight = clientHeight;
                        setRef(this.props.clientHeightRef, clientHeight);
                    }
                    const bottomScrollbarWidth = Math.round(this.el.getBoundingClientRect().height - clientHeight);
                    if (bottomScrollbarWidth !== this.bottomScrollbarWidth) {
                        this.bottomScrollbarWidth = bottomScrollbarWidth;
                        setRef(this.props.bottomScrollbarWidthRef, bottomScrollbarWidth);
                    }
                });
            }
        };
    }
    render() {
        const { props } = this;
        // if there's only one axis that needs scrolling, the other axis will unintentionally have
        // scrollbars too if we don't force to 'hidden'
        const fallbackOverflow = (props.horizontal || props.vertical) ? 'hidden' : '';
        return (jsxs("div", { ref: this.handleEl, className: joinClassNames(props.className, classNames.noPadding, classNames.rel, // for children fillTop/fillStart
            props.hideScrollbars && classNames.noScrollbars, classNames.internalScroller), style: {
                ...props.style,
                overflowX: (props.horizontal ? 'auto' : fallbackOverflow),
                overflowY: (props.vertical ? 'auto' : fallbackOverflow),
            }, children: [props.children, Boolean(props.clientWidthRef) && (jsx("div", { ref: this.handleHRuler, className: classNames.fillTop })), Boolean(props.clientHeightRef || props.bottomScrollbarWidthRef) && (jsx("div", { ref: this.handleVRuler, className: classNames.fillStart }))] }));
    }
    endScroll() {
        this.listener.endScroll();
    }
    // Public API
    // -----------------------------------------------------------------------------------------------
    get x() {
        const { el } = this;
        return el ? getNormalizedScrollX(el) : 0;
    }
    get y() {
        const { el } = this;
        return el ? el.scrollTop : 0;
    }
    scrollTo({ x, y }) {
        const { el } = this;
        if (el) {
            if (y != null) {
                el.scrollTop = y;
            }
            if (x != null) {
                setNormalizedScrollX(el, x);
            }
        }
    }
    addScrollStartListener(handler) {
        this.listener.emitter.on('scrollStart', handler);
    }
    removeScrollStartListener(handler) {
        this.listener.emitter.off('scrollStart', handler);
    }
    addScrollEndListener(handler) {
        this.listener.emitter.on('scrollEnd', handler);
    }
    removeScrollEndListener(handler) {
        this.listener.emitter.off('scrollEnd', handler);
    }
}
// Public API
// -------------------------------------------------------------------------------------------------
// We can drop normalization when support for Chromium-based <86 is dropped (see Notion)
function getNormalizedScrollX(el) {
    const { scrollLeft } = el;
    const isRtl = computeElIsRtl(el);
    return isRtl ? getNormalizedRtlScrollX(scrollLeft, el) : scrollLeft;
}
function setNormalizedScrollX(el, x) {
    const isRtl = computeElIsRtl(el);
    el.scrollLeft = isRtl ? getNormalizedRtlScrollLeft(x, el) : x;
}
/*
Returns a value in the 'reverse' system
*/
function getNormalizedRtlScrollX(scrollLeft, el) {
    switch (getRtlScrollerSystem()) {
        case 'positive':
            return el.scrollWidth - el.clientWidth - scrollLeft;
        case 'negative':
            return -scrollLeft;
    }
    return scrollLeft;
}
/*
Receives a value in the 'reverse' system
TODO: is this really the same equations as getNormalizedRtlScrollX??? I think so
  If so, consolidate. With isRtl check too
*/
function getNormalizedRtlScrollLeft(x, el) {
    switch (getRtlScrollerSystem()) {
        case 'positive':
            return el.scrollWidth - el.clientWidth - x;
        case 'negative':
            return -x;
    }
    return x;
}
let _rtlScrollerSystem;
function getRtlScrollerSystem() {
    return _rtlScrollerSystem || (_rtlScrollerSystem = detectRtlScrollerSystem());
}
function detectRtlScrollerSystem() {
    let el = document.createElement('div');
    el.style.position = 'absolute';
    el.style.top = '-1000px';
    el.style.width = '100px'; // must be at least the side of scrollbars or you get inaccurate values (#7335)
    el.style.height = '100px'; // "
    el.style.overflow = 'scroll';
    el.style.direction = 'rtl';
    let innerEl = document.createElement('div');
    innerEl.style.width = '200px';
    innerEl.style.height = '200px';
    el.appendChild(innerEl);
    document.body.appendChild(el);
    let system;
    if (el.scrollLeft > 0) {
        system = 'positive'; // scroll is a positive number from the left edge
    }
    else {
        el.scrollLeft = 50;
        if (el.scrollLeft > 0) {
            system = 'reverse'; // scroll is a positive number from the right edge
        }
        else {
            system = 'negative'; // scroll is a negative number from the right edge
        }
    }
    el.remove();
    return system;
}

class StandardEvent extends BaseComponent {
    constructor() {
        super(...arguments);
        // memo
        this.buildPublicEvent = memoize((context, eventDef, eventInstance) => new EventImpl(context, eventDef, eventInstance));
        this.handleEl = (el) => {
            this.el = el;
            setRef(this.props.elRef, el);
            if (el) {
                setElEventRange(el, this.props.eventRange);
            }
        };
    }
    render() {
        const { props, context } = this;
        const { options } = context;
        const { eventRange } = props;
        const eventUi = eventRange.ui;
        const timeFormat = options.eventTimeFormat || props.defaultTimeFormat;
        const timeText = props.forcedTimeText ?? buildEventRangeTimeText(timeFormat, eventRange, // just for def/instance
        props.slicedStart, props.slicedEnd, props.isStart, props.isEnd, context, props.defaultDisplayEventTime, props.defaultDisplayEventEnd);
        const [tag, attrs, isInteractive] = getEventTagAndAttrs(eventRange, context);
        const eventApi = this.buildPublicEvent(context, eventRange.def, eventRange.instance);
        const isDraggable = !props.disableDragging && computeEventRangeDraggable(eventRange, context);
        const isBlock = /row|column/.test(props.display);
        const subcontentRenderProps = {
            ...props.renderProps, // first, so built-in props take precedence
            event: eventApi,
            isNarrow: props.isNarrow || false,
            isShort: props.isShort || false,
            timeText,
        };
        const renderProps = {
            ...props.renderProps, // first, so built-in props take precedence
            event: eventApi, // make stable. everything else atomic. FYI, eventRange unfortunately gets reconstructed a lot, but def/instance is stable
            view: context.viewApi,
            timeText: timeText,
            color: eventUi.color || options.eventColor,
            contrastColor: eventUi.contrastColor || options.eventContrastColor,
            isDraggable,
            isStartResizable: !props.disableResizing && props.isStart && eventUi.durationEditable && options.eventResizableFromStart,
            isEndResizable: !props.disableResizing && props.isEnd && eventUi.durationEditable,
            isMirror: props.isMirror,
            isStart: Boolean(props.isStart),
            isEnd: Boolean(props.isEnd),
            isFirst: Boolean(props.isFirst),
            isLast: Boolean(props.isLast),
            isPast: Boolean(props.isPast), // TODO: don't cast. getDateMeta does it
            isFuture: Boolean(props.isFuture), // TODO: don't cast. getDateMeta does it
            isToday: Boolean(props.isToday), // TODO: don't cast. getDateMeta does it
            isSelected: Boolean(props.isSelected),
            isDragging: Boolean(props.isDragging),
            isResizing: Boolean(props.isResizing),
            isInteractive,
            isNarrow: props.isNarrow || false,
            isShort: props.isShort || false,
            level: props.level || 0,
            timeClass: joinClassNames(generateClassName(options.eventTimeClass, subcontentRenderProps), isBlock && generateClassName(options.blockEventTimeClass, subcontentRenderProps), props.display === 'row' && generateClassName(options.rowEventTimeClass, subcontentRenderProps), props.display === 'column' && generateClassName(options.columnEventTimeClass, subcontentRenderProps), props.display === 'list-item' && generateClassName(options.listItemEventTimeClass, subcontentRenderProps)),
            titleClass: joinClassNames(generateClassName(options.eventTitleClass, subcontentRenderProps), isBlock && generateClassName(options.blockEventTitleClass, subcontentRenderProps), props.display === 'row' && generateClassName(options.rowEventTitleClass, subcontentRenderProps), props.display === 'column' && generateClassName(options.columnEventTitleClass, subcontentRenderProps), props.display === 'list-item' && generateClassName(options.listItemEventTitleClass, subcontentRenderProps), props.display === 'row' && options.rowEventTitleSticky && classNames.stickyS, props.display === 'column' && options.columnEventTitleSticky && classNames.stickyT),
            options: { eventOverlap: Boolean(options.eventOverlap) },
        };
        const outerClassName = joinClassNames(// already includes eventClass below
        isBlock && generateClassName(options.blockEventClass, renderProps), props.display === 'row' && generateClassName(options.rowEventClass, renderProps), props.display === 'column' && generateClassName(options.columnEventClass, renderProps), props.display === 'list-item' && generateClassName(options.listItemEventClass, renderProps), eventUi.className, props.className, props.display === 'column'
            ? classNames.flexCol
            : classNames.flexRow, (eventRange.def.url || isDraggable) && classNames.cursorPointer, classNames.internalEvent, props.isMirror && classNames.internalEventMirror, isDraggable && classNames.internalEventDraggable, renderProps.isSelected && classNames.internalEventSelected, (renderProps.isStartResizable || renderProps.isEndResizable) && classNames.internalEventResizable);
        const beforeClassName = joinClassNames(generateClassName(options.eventBeforeClass, renderProps), isBlock && generateClassName(options.blockEventBeforeClass, renderProps), props.display === 'row' && generateClassName(options.rowEventBeforeClass, renderProps), props.display === 'column' && generateClassName(options.columnEventBeforeClass, renderProps), props.display === 'list-item' && generateClassName(options.listItemEventBeforeClass, renderProps));
        const afterClassName = joinClassNames(generateClassName(options.eventAfterClass, renderProps), isBlock && generateClassName(options.blockEventAfterClass, renderProps), props.display === 'row' && generateClassName(options.rowEventAfterClass, renderProps), props.display === 'column' && generateClassName(options.columnEventAfterClass, renderProps), props.display === 'list-item' && generateClassName(options.listItemEventAfterClass, renderProps));
        const innerClassName = joinClassNames(generateClassName(options.eventInnerClass, renderProps), isBlock && generateClassName(options.blockEventInnerClass, renderProps), props.display === 'row' && generateClassName(options.rowEventInnerClass, renderProps), props.display === 'column' && generateClassName(options.columnEventInnerClass, renderProps), props.display === 'list-item' && generateClassName(options.listItemEventInnerClass, renderProps), !props.disableLiquid && classNames.liquid);
        const beforeContent = props.display === 'row' && options.rowEventBeforeContent;
        const afterContent = props.display === 'row' && options.rowEventAfterContent;
        return (jsx(ContentContainer, { tag: tag, attrs: {
                ...props.attrs,
                ...attrs,
                // HACK because this event-element gets attached to root during some dragging
                dir: (props.isDragging && options.direction === 'rtl') ? 'rtl' : undefined,
            }, className: outerClassName, style: {
                '--fc-event-color': renderProps.color,
                '--fc-event-contrast-color': renderProps.contrastColor,
            }, elRef: this.handleEl, renderProps: renderProps, generatorName: "eventContent", customGenerator: options.eventContent, defaultGenerator: renderInnerContent, classNameGenerator: options.eventClass, didMount: options.eventDidMount, willUnmount: options.eventWillUnmount, children: (InnerContent) => (jsxs(Fragment, { children: [Boolean(renderProps.isSelected && isBlock) && (jsx("div", { className: props.display === 'column'
                            ? classNames.hitX
                            : classNames.hitY })), (beforeClassName || beforeContent) && (jsxs("div", { className: joinClassNames(beforeClassName, !props.disableZindexes && classNames.z1, renderProps.isStartResizable && joinClassNames(props.display === 'column'
                            ? classNames.cursorResizeT
                            : classNames.cursorResizeS, 
                        // these classnames required for dnd
                        classNames.internalEventResizer, classNames.internalEventResizerStart)), children: [beforeContent && (jsx(ContentContainer, { tag: 'div', style: { display: 'contents' }, attrs: { 'aria-hidden': true }, renderProps: renderProps, generatorName: undefined, customGenerator: beforeContent })), Boolean(renderProps.isStartResizable && renderProps.isSelected) && (jsx("div", { className: classNames.hit }))] })), jsx(InnerContent, { tag: "div", className: joinClassNames(innerClassName, !props.disableZindexes && classNames.z0) }), (afterClassName || afterContent) && (jsxs("div", { className: joinClassNames(afterClassName, !props.disableZindexes && classNames.z1, renderProps.isEndResizable && joinClassNames(props.display === 'column'
                            ? classNames.cursorResizeB
                            : classNames.cursorResizeE, 
                        // these classnames required for dnd
                        classNames.internalEventResizer, classNames.internalEventResizerEnd)), children: [afterContent && (jsx(ContentContainer, { tag: 'div', style: { display: 'contents' }, attrs: { 'aria-hidden': true }, renderProps: renderProps, generatorName: undefined, customGenerator: afterContent })), Boolean(renderProps.isEndResizable && renderProps.isSelected) && (jsx("div", { className: classNames.hit }))] }))] })) }));
    }
    componentDidUpdate(prevProps) {
        if (this.el && this.props.eventRange !== prevProps.eventRange) {
            setElEventRange(this.el, this.props.eventRange);
        }
    }
}
StandardEvent.addPropsEquality({
    seg: isPropsEqualShallow,
});
function renderInnerContent(innerProps) {
    return (jsxs(Fragment, { children: [innerProps.timeText && (jsx("div", { className: innerProps.timeClass, children: innerProps.timeText })), jsx("div", { className: innerProps.titleClass, children: innerProps.event.title || jsx(Fragment, { children: "\u00A0" }) })] }));
}

export { DateComponent as D, FULL_DATE_FORMAT as F, NowTimer as N, StandardEvent as S, ViewContainer as V, WEEKDAY_ONLY_FORMAT as W, findDayNumberText as a, buildNavLinkAttrs as b, buildDateStr as c, Scroller as d, findMonthText as e, findWeekdayText as f, getDateMeta as g, DelayedRunner as h };
