import { jsx } from 'react/jsx-runtime';
import { B as BaseComponent, m as memoize } from './ad0714f5.js';
import { N as NowTimer } from './c893d83b.js';
import { b as buildDayTableModel, a as buildDateRowConfigs, c as createDayHeaderFormatter, D as DayTableSlicer } from './367ade1c.js';
import { D as DayGridLayout } from './efb208b4.js';
import { T as TableDateProfileGenerator } from './cbc7722d.js';

class DayGridView extends BaseComponent {
    constructor() {
        super(...arguments);
        // memo
        this.buildDayTableModel = memoize(buildDayTableModel);
        this.buildDateRowConfigs = memoize(buildDateRowConfigs);
        this.createDayHeaderFormatter = memoize(createDayHeaderFormatter);
        // internal
        this.slicer = new DayTableSlicer();
    }
    render() {
        const { props, context } = this;
        const { dateProfile } = props;
        const { options, dateEnv } = context;
        const dayTableModel = this.buildDayTableModel(dateProfile, context.dateProfileGenerator, dateEnv);
        const datesRepDistinctDays = dayTableModel.rowCount === 1;
        const dayHeaderFormat = this.createDayHeaderFormatter(context.options.dayHeaderFormat, datesRepDistinctDays, dayTableModel.colCount);
        const slicedProps = this.slicer.sliceProps(props, dateProfile, options.nextDayThreshold, context, dayTableModel);
        return (jsx(NowTimer, { unit: "day", children: (nowDate, todayRange) => {
                const headerTiers = this.buildDateRowConfigs(dayTableModel.headerDates, datesRepDistinctDays, dateProfile, todayRange, dayHeaderFormat, context);
                return (jsx(DayGridLayout, { labelId: props.labelId, labelStr: props.labelStr, dateProfile: dateProfile, todayRange: todayRange, cellRows: dayTableModel.cellRows, forPrint: props.forPrint, className: props.className, 
                    // header content
                    headerTiers: headerTiers, 
                    // body content
                    fgEventSegs: slicedProps.fgEventSegs, bgEventSegs: slicedProps.bgEventSegs, businessHourSegs: slicedProps.businessHourSegs, dateSelectionSegs: slicedProps.dateSelectionSegs, eventDrag: slicedProps.eventDrag, eventResize: slicedProps.eventResize, eventSelection: slicedProps.eventSelection }));
            } }));
    }
}

var dayGridPlugin = {
    name: 'daygrid',
    initialView: 'dayGridMonth',
    views: {
        dayGrid: {
            component: DayGridView,
            dateProfileGeneratorClass: TableDateProfileGenerator,
        },
        dayGridDay: {
            type: 'dayGrid',
            duration: { days: 1 },
        },
        dayGridWeek: {
            type: 'dayGrid',
            duration: { weeks: 1 },
        },
        dayGridMonth: {
            type: 'dayGrid',
            duration: { months: 1 },
            fixedWeekCount: true,
        },
        dayGridYear: {
            type: 'dayGrid',
            duration: { years: 1 },
        },
    },
};

export { dayGridPlugin as d };
