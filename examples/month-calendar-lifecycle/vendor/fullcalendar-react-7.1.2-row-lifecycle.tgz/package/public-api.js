import { joinDateTimeFormatParts, DateEnv } from '@full-ui/headless-calendar';
import { c as createFormatter, B as BASE_OPTION_DEFAULTS, s as sliceEventStore } from './chunks/6e87ff0f.js';
import { b as buildLocale, o as organizeRawLocales } from './chunks/26e567a2.js';
export { J as JsonRequestError, g as globalLocales, a as globalPlugins } from './chunks/26e567a2.js';
export { j as joinClassNames } from './chunks/ebfc0d8f.js';

const blankButtonState = {
    text: '', hint: '', isDisabled: false,
};
class CalendarController {
    constructor(handleDateChange) {
        this.handleDateChange = handleDateChange;
    }
    today() {
        this.calendarApi?.today();
    }
    prev() {
        this.calendarApi?.prev();
    }
    next() {
        this.calendarApi?.next();
    }
    prevYear() {
        this.calendarApi?.prevYear();
    }
    nextYear() {
        this.calendarApi?.nextYear();
    }
    gotoDate(zonedDateInput) {
        this.calendarApi?.gotoDate(zonedDateInput);
    }
    incrementDate(duration) {
        this.calendarApi?.incrementDate(duration);
    }
    changeView(viewType) {
        this.calendarApi?.changeView(viewType);
    }
    get view() {
        return this.calendarApi?.view;
    }
    getDate() {
        return this.calendarApi?.getDate();
    }
    getButtonState() {
        const { calendarApi } = this;
        return (calendarApi && calendarApi.getButtonState()) || {
            today: blankButtonState,
            prev: blankButtonState,
            next: blankButtonState,
            prevYear: blankButtonState,
            nextYear: blankButtonState,
        };
    }
    _setApi(calendarApi) {
        if (this.calendarApi !== calendarApi) {
            if (this.calendarApi) {
                this.calendarApi.off('datesSet', this.handleDateChange);
                this.calendarApi = undefined;
            }
            if (calendarApi) {
                this.calendarApi = calendarApi;
                calendarApi.on('datesSet', this.handleDateChange);
            }
        }
    }
}

function formatDate(dateInput, options = {}) {
    let dateEnv = buildDateEnv(options);
    let formatter = createFormatter(options);
    let dateMeta = dateEnv.createMarkerMeta(dateInput);
    if (!dateMeta) { // TODO: warning?
        return '';
    }
    return joinDateTimeFormatParts(dateEnv.formatToParts(dateMeta.marker, formatter, {
        instantMs: dateMeta.instantMs,
    }));
}
function formatRange(startInput, endInput, options) {
    let dateEnv = buildDateEnv(typeof options === 'object' && options ? options : {}); // pass in if non-null object
    let formatter = createFormatter(options);
    let startMeta = dateEnv.createMarkerMeta(startInput);
    let endMeta = dateEnv.createMarkerMeta(endInput);
    if (!startMeta || !endMeta) { // TODO: warning?
        return '';
    }
    return joinDateTimeFormatParts(dateEnv.formatRangeToParts(startMeta.marker, endMeta.marker, formatter, {
        isEndExclusive: options.isEndExclusive,
        startInstantMs: startMeta.instantMs,
        endInstantMs: endMeta.instantMs,
    }));
}
// TODO: more DRY and optimized
function buildDateEnv(settings) {
    let locale = buildLocale(settings.locale || 'en', organizeRawLocales([]).map); // TODO: don't hardcode 'en' everywhere
    return new DateEnv({
        timeZone: BASE_OPTION_DEFAULTS.timeZone,
        calendarSystem: 'gregory',
        ...settings,
        locale,
    });
}

/*
if nextDayThreshold is specified, slicing is done in an all-day fashion.
you can get nextDayThreshold from context.nextDayThreshold
*/
function sliceEvents(props, allDay) {
    return sliceEventStore(props.eventStore, props.eventUiBases, props.dateProfile.activeRange, allDay ? props.nextDayThreshold : null).fg;
}

const version = '7.1.2';

export { CalendarController, formatDate, formatRange, sliceEvents, version };
