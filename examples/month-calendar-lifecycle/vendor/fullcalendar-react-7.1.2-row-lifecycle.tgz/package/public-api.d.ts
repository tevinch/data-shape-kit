import { L as LocaleInput, P as PluginInput } from './chunks/03e73926.js';
export { y as AllDayHeaderInfo, A as AllowFunc, B as BusinessHoursInput, a2 as ButtonDisplay, a0 as ButtonGroupInfo, a1 as ButtonInfo, $ as ButtonInput, aj as ButtonState, al as ButtonStateMap, a as CalendarApi, C as CalendarController, R as CalendarDisplayInfo, e as CalendarListeners, d as CalendarOptions, p as ClassNameGenerator, o as ClassNameInput, m as ConstraintInput, q as ContentGenerator, l as CssDimValue, ae as CustomRenderingHandler, af as CustomRenderingStore, aD as DateClickInfo, ah as DatePointApi, Y as DateSelectInfo, ai as DateSelectionApi, ag as DateSpanApi, D as DateSpanInput, v as DateTimeFormatPartWithWeek, Z as DateUnselectInfo, a9 as DatesSetInfo, G as DayCellInfo, F as DayHeaderDividerInfo, z as DayHeaderInfo, H as DayLaneInfo, r as DidMountHandler, aE as DropInfo, aa as EventAddInfo, b as EventApi, ab as EventChangeInfo, U as EventClickInfo, a6 as EventDisplayInfo, ay as EventDragStartInfo, az as EventDragStopInfo, ac as EventDropInfo, X as EventHoveringInfo, j as EventInput, k as EventInputTransformer, aG as EventLeaveInfo, aF as EventReceiveInfo, ad as EventRemoveInfo, c as EventRenderRange, aC as EventResizeDoneInfo, aA as EventResizeStartInfo, aB as EventResizeStopInfo, au as EventSegment, E as EventSourceApi, h as EventSourceFunc, i as EventSourceFuncInfo, g as EventSourceInput, a7 as EventTextInfo, am as FormatterInput, I as InlineWeekNumberInfo, ap as ListDayHeaderInfo, aq as ListDayHeaderInnerInfo, ar as ListDayInfo, L as LocaleInput, an as LocaleSingularArg, av as MoreLinkAction, ax as MoreLinkHandler, w as MoreLinkInfo, aw as MoreLinkSimpleAction, M as MountInfo, ak as NavButtonState, ao as NoEventsInfo, N as NowIndicatorHeaderInfo, t as NowIndicatorLineInfo, O as OverlapFunc, P as PluginInput, at as SingleMonthHeaderInfo, as as SingleMonthInfo, x as SlotHeaderInfo, S as SlotLaneInfo, K as TableBodyInfo, T as TableDisplayInfo, Q as TableHeaderInfo, a3 as ToolbarElementInput, a5 as ToolbarInfo, _ as ToolbarInput, a4 as ToolbarSectionInfo, V as ViewApi, n as ViewComponentType, a8 as ViewContentInfo, J as ViewDisplayInfo, f as ViewOptions, u as WeekNumberHeaderInfo, W as WillUnmountHandler, s as sliceEvents } from './chunks/03e73926.js';
import { NativeDateFormatterOptions, DateInput } from '@full-ui/headless-calendar';
export { DateInput, DateRangeInput, Duration, DurationInput, WeekNumberCalculation } from '@full-ui/headless-calendar';
export { J as JsonRequestError } from './chunks/f6a6f5b3.js';

interface FormatDateOptions extends NativeDateFormatterOptions {
    locale?: string;
}
interface FormatRangeOptions extends FormatDateOptions {
    isEndExclusive?: boolean;
}
declare function formatDate(dateInput: DateInput, options?: FormatDateOptions): string;
declare function formatRange(startInput: DateInput, endInput: DateInput, options: FormatRangeOptions): string;

type ClassValue = string | undefined | null | false | number;
declare function joinClassNames(...args: ClassValue[]): string;

declare const globalLocales: LocaleInput[];

declare const globalPlugins: PluginInput[];

declare const version: string;

export { FormatDateOptions, FormatRangeOptions, formatDate, formatRange, globalLocales, globalPlugins, joinClassNames, version };
